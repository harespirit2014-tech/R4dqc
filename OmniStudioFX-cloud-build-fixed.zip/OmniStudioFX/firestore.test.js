const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const DATABASE_ID = "ai-studio-android-omnistud-41f4109c-3b44-44c6-b562-a057820af5ba";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

function dbFor(uid) {
  if (!uid) {
    return testEnv.unauthenticatedContext().firestore(DATABASE_ID);
  }
  return testEnv.authenticatedContext(uid).firestore(DATABASE_ID);
}

test("Unauthenticated users cannot read or write any user collections", async () => {
  const unauth = dbFor(null);
  await assertFails(unauth.collection("users").doc(ALICE_UID).get());
  await assertFails(unauth.collection("users").doc(ALICE_UID).collection("rooms").get());
  await assertFails(
    unauth.collection("users").doc(ALICE_UID).collection("bulbs").doc("bulb_1").set({
      userId: ALICE_UID,
      name: "Unauthorized Bulb",
      floorIndex: 0,
      roomName: "Lab",
      powered: true,
      brightnessPct: 80,
      colorTempKelvin: 4000,
      lifiSynced: true,
      createdAt: new Date(Date.now() - 1000),
      updatedAt: new Date(Date.now() - 1000),
    })
  );
});

test("Owner can create and update UserProfile, rejecting ghost fields and immutable mutations", async () => {
  const aliceDb = dbFor(ALICE_UID);
  const created = new Date(Date.now() - 5000);
  const profileRef = aliceDb.collection("users").doc(ALICE_UID);

  await assertSucceeds(
    profileRef.set({
      userId: ALICE_UID,
      displayName: "Alice RF",
      email: "alice@example.com",
      globeLinkedEmail: "alice@globe.test",
      slabThresholdDb: -15.5,
      zGateStrict: true,
      createdAt: created,
      updatedAt: created,
    })
  );

  await assertSucceeds(
    profileRef.update({
      slabThresholdDb: -17.0,
      zGateStrict: false,
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Reject ghost field
  await assertFails(
    profileRef.update({
      isAdmin: true,
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Reject createdAt mutation
  await assertFails(
    profileRef.update({
      createdAt: new Date(Date.now() - 500),
      updatedAt: new Date(Date.now() - 500),
    })
  );
});

test("Owner can CRUD rooms, bulbs, and AI insights; @DocumentId id key and tampered timestamps fail", async () => {
  const aliceDb = dbFor(ALICE_UID);
  const now = new Date(Date.now() - 5000);

  // Room create & query
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("rooms").doc("room_1").set({
      userId: ALICE_UID,
      name: "Tech Lab",
      floorIndex: 0,
      posX: -2.2,
      posY: -1.6,
      width: 2.4,
      depth: 2.0,
      hasAp: true,
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("rooms").get()
  );

  // Reject extra @DocumentId 'id' field in payload
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("rooms").doc("room_2").set({
      id: "room_2",
      userId: ALICE_UID,
      name: "Bad Room",
      floorIndex: 0,
      posX: 0,
      posY: 0,
      width: 2,
      depth: 2,
      hasAp: false,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Bulb create + partial update
  const bulbRef = aliceDb.collection("users").doc(ALICE_UID).collection("bulbs").doc("bulb_1");
  await assertSucceeds(
    bulbRef.set({
      userId: ALICE_UID,
      name: "Globe Bulb Basement 1",
      floorIndex: 0,
      roomName: "Tech Lab",
      powered: true,
      brightnessPct: 90,
      colorTempKelvin: 4500,
      lifiSynced: true,
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertSucceeds(
    bulbRef.update({
      powered: false,
      brightnessPct: 45,
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Insight create + reject future timestamp
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("insights").doc("ins_1").set({
      userId: ALICE_UID,
      title: "Strong 5GHz Basement Lock",
      summary: "Z-Gate isolated 2 same-floor APs cleanly.",
      category: "AI Spatial Audit",
      healthScore: 91,
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("insights").doc("ins_2").set({
      userId: ALICE_UID,
      title: "Future Spoof",
      summary: "Tampered timestamp",
      category: "AI Spatial Audit",
      healthScore: 99,
      createdAt: new Date(Date.now() + 60000),
      updatedAt: new Date(Date.now() + 60000),
    })
  );
});

test("Cross-user isolation: Bob cannot read or write Alice's profile, rooms, bulbs, or insights", async () => {
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    const adminDb = ctx.firestore(DATABASE_ID);
    const ts = new Date(Date.now() - 10000);
    await adminDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Alice",
      email: "alice@example.com",
      slabThresholdDb: -15.5,
      zGateStrict: true,
      createdAt: ts,
      updatedAt: ts,
    });
    await adminDb.collection("users").doc(ALICE_UID).collection("bulbs").doc("bulb_a").set({
      userId: ALICE_UID,
      name: "Alice Bulb",
      floorIndex: 0,
      roomName: "Lab",
      powered: true,
      brightnessPct: 80,
      colorTempKelvin: 4000,
      lifiSynced: true,
      createdAt: ts,
      updatedAt: ts,
    });
  });

  const bobDb = dbFor(BOB_UID);
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("bulbs").get());
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("bulbs").doc("bulb_a").update({
      powered: false,
      updatedAt: new Date(Date.now() - 1000),
    })
  );
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("bulbs").doc("bulb_a").delete()
  );
});
