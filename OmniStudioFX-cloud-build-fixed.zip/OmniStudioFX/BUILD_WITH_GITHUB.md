# Build OmniStudioFX without Android Studio

This project can be built on GitHub's hosted Linux runner. You do not need Android Studio or an Android SDK installed on your phone/computer.

## One-time setup

1. Sign in to GitHub (create a free account if needed).
2. Create a new repository named `OmniStudioFX`. A private repository is fine.
3. Upload the **contents** of this project folder to the repository (not the ZIP file itself), preserving folders such as `app`, `gradle`, and `.github`.
4. Commit the upload to the `main` branch.

The workflow at `.github/workflows/android-apk.yml` runs automatically when you push to `main`/`master`.

## Download the APK

1. Open the repository on GitHub.
2. Select the **Actions** tab.
3. Open the latest **Build OmniStudioFX APK** run.
4. Wait for the job to finish with a green check.
5. Under **Artifacts**, download `OmniStudioFX-debug-apk`.
6. Extract the downloaded artifact ZIP. It contains `app-debug.apk`.
7. Transfer `app-debug.apk` to your Android phone and install it. Android may ask you to allow installation from that source.

You can also start a build manually: **Actions → Build OmniStudioFX APK → Run workflow**.

## Notes

- This creates a **debug-signed APK for testing**, not a Play Store release.
- The included `debug.keystore` is used only for this debug build. Do not use it as a production upload key.
- A successful workflow run is required before an APK exists. If the build fails, open the run and inspect the `Build debug APK` log; share the error log here and I can help fix it.
- The workflow installs Android SDK Platform 36.1 and Build Tools 36.0.0, then runs the Gradle version declared by the project (9.3.1).
- Firebase/Gemini features may still require correct Firebase console setup, App Check configuration, and any required service settings. A successful compile does not by itself validate live backend functionality.
