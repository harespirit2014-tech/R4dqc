# OmniStudioFX Android build

## Debug APK (recommended for device testing)

1. Install Android Studio with Android SDK Platform 36 (including API 36.1 if offered) and Android SDK Build-Tools.
2. Install a compatible JDK (JDK 17 or 21; the project currently uses Java 11 source/target compatibility).
3. Open this folder (`OmniStudioFX`) in Android Studio and allow Gradle sync to complete. The project requests Gradle 9.3.1 and Android Gradle Plugin 9.1.1; Android Studio/Gradle may request compatible JDK configuration.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**, or run `:app:assembleDebug` from the Gradle tool window.
5. The debug APK is written to `app/build/outputs/apk/debug/app-debug.apk`.

The included `debug.keystore` is only for local debug builds. Do not use it as a Play upload key or distribute it as a release signing key.

## Release APK

The release build requires a private upload keystore and the environment variables `KEYSTORE_PATH`, `STORE_PASSWORD`, and `KEY_PASSWORD`. The project expects the key alias `upload`. Do not commit or share your private keystore/passwords. A new key cannot replace an existing Play App Signing upload key without the appropriate Play Console reset process.

## Firebase / AI

The project includes `app/google-services.json` and Firebase App Check reCAPTCHA configuration. Firebase service access still depends on the Firebase project's console configuration, registered package/SHA fingerprints, enabled products, and App Check settings. No Gemini API key is required by the checked-in `.env.example`; it states that Firebase AI Logic uses Firebase App Check.

## Build environment note

This source archive does not include `gradlew`, `gradlew.bat`, or `gradle/wrapper/gradle-wrapper.jar`. Android Studio can import the project and use its configured Gradle distribution, or a developer can generate the wrapper from an installed Gradle distribution. A successful APK build has not yet been produced in the current workspace because Android SDK and Gradle are not installed here and external DNS/network access is unavailable.

## Build without Android Studio

See [BUILD_WITH_GITHUB.md](BUILD_WITH_GITHUB.md). The included GitHub Actions workflow builds a debug APK on a hosted runner and publishes it as a downloadable workflow artifact.
