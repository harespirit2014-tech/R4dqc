package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.TipsAndUpdates
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.UserSettings
import com.example.data.model.AiAuditResult
import com.example.data.model.AiInsightRecord
import com.example.data.model.ChatMessage
import com.example.data.model.SensorStatus
import com.example.data.model.TelemetryPoint
import com.example.data.sensors.WifiScanSnapshot
import com.example.ui.AiAuditUiState
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPillBadge
import com.example.ui.components.TelemetryStatCard
import com.example.ui.components.TelemetryTrendChart
import com.example.ui.theme.AmberCalibration
import com.example.ui.theme.CoralAlert
import com.example.ui.theme.DeepSpaceBg
import com.example.ui.theme.HoloCyan
import com.example.ui.theme.IndigoAi
import com.example.ui.theme.SpaceBorder
import com.example.ui.theme.SpaceCard
import com.example.ui.theme.SpaceCardElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.ZGateEmerald

@Composable
fun AiAnalyticsScreen(
    settings: UserSettings,
    sensorStatus: SensorStatus,
    wifiSnapshot: WifiScanSnapshot,
    telemetrySeries: List<TelemetryPoint>,
    aiAuditState: AiAuditUiState,
    chatMessages: List<ChatMessage>,
    insightsHistory: List<AiInsightRecord>,
    hasNotificationPerm: Boolean,
    onRequestNotificationPerm: () -> Unit,
    onToggleAutoNotify: (Boolean) -> Unit,
    onSendTestNotification: () -> Unit,
    onRunAiAudit: () -> Unit,
    onSendCopilotMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var copilotInput by remember { mutableStateOf("") }
    val latestPoint = telemetrySeries.lastOrNull()

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column {
                Text(
                    text = "AI Analytics & Insight Alerts",
                    style = MaterialTheme.typography.headlineMedium,
                    color = TextPrimary
                )
                Text(
                    text = "Real-time telemetry synthesis powered by Gemini 3.8 Flash.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            }
        }

        // Real-Time KPIs
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TelemetryStatCard(
                    label = "Avg RSSI",
                    value = latestPoint?.let { "${it.avgRssiDbm.toInt()} dBm" } ?: "-- dBm",
                    valueColor = HoloCyan,
                    modifier = Modifier.weight(1f)
                )
                TelemetryStatCard(
                    label = "Ambient Lux",
                    value = sensorStatus.ambientLux?.let { "${it.toInt()} lx" } ?: "N/A",
                    valueColor = AmberCalibration,
                    modifier = Modifier.weight(1f)
                )
                TelemetryStatCard(
                    label = "APs Tracked",
                    value = "${wifiSnapshot.nodes.size}",
                    valueColor = ZGateEmerald,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Live Chart
        item {
            TelemetryTrendChart(
                points = telemetrySeries,
                modifier = Modifier.fillMaxWidth()
            )
        }

        // Push Notification Engagement Hub
        item {
            Surface(
                color = SpaceCard,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, SpaceBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    SectionHeader(
                        title = "Push Insight Notifications",
                        subtitle = "Stay alerted on RF anomalies, LiFi sync & LED locks.",
                        icon = Icons.Default.NotificationsActive,
                        accent = ZGateEmerald
                    )

                    if (!hasNotificationPerm) {
                        Button(
                            onClick = onRequestNotificationPerm,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = AmberCalibration,
                                contentColor = DeepSpaceBg
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("request_notif_perm_btn")
                        ) {
                            Text("Enable Android Push Notifications")
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Auto-notify on new AI & Rogue AP insights",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        Switch(
                            checked = settings.autoAiNotifications,
                            onCheckedChange = onToggleAutoNotify,
                            modifier = Modifier.testTag("auto_notify_switch")
                        )
                    }

                    OutlinedButton(
                        onClick = onSendTestNotification,
                        border = BorderStroke(1.dp, HoloCyan.copy(alpha = 0.5f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("test_notif_btn")
                    ) {
                        Text("Dispatch Live Insight Notification Now", color = HoloCyan)
                    }
                }
            }
        }

        // Gemini AI Audit Action & Results
        item {
            Surface(
                color = SpaceCard,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, IndigoAi.copy(alpha = 0.45f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        SectionHeader(
                            title = "Gemini AI Telemetry Audit",
                            subtitle = "Analyzes live 3D Z-Gate, Wi-Fi, LiFi & GPS",
                            icon = Icons.Default.AutoAwesome,
                            accent = IndigoAi
                        )
                    }

                    Button(
                        onClick = onRunAiAudit,
                        enabled = aiAuditState !is AiAuditUiState.Loading,
                        colors = ButtonDefaults.buttonColors(containerColor = IndigoAi, contentColor = DeepSpaceBg),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("run_gemini_audit_btn")
                    ) {
                        if (aiAuditState is AiAuditUiState.Loading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                color = DeepSpaceBg,
                                strokeWidth = 2.dp
                            )
                            Spacer(Modifier.width(8.dp))
                            Text("Analyzing Live Telemetry...")
                        } else {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Run Gemini AI Audit")
                        }
                    }

                    when (aiAuditState) {
                        is AiAuditUiState.Idle -> {
                            Text(
                                "Tap above to synthesize real-time sensor, Wi-Fi RTT, Globe Suite bulb, and location guidance telemetry.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary
                            )
                        }

                        is AiAuditUiState.Loading -> Unit

                        is AiAuditUiState.Error -> {
                            Surface(
                                color = CoralAlert.copy(alpha = 0.14f),
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, CoralAlert.copy(alpha = 0.5f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = aiAuditState.message,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = CoralAlert,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        }

                        is AiAuditUiState.Success -> {
                            AiAuditResultCard(aiAuditState.result)
                        }
                    }
                }
            }
        }

        // Interactive AI Copilot Chat
        item {
            Surface(
                color = SpaceCard,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, SpaceBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    SectionHeader(
                        title = "OmniStudio AI Copilot",
                        subtitle = "Ask questions grounded in live device telemetry",
                        icon = Icons.Default.TipsAndUpdates,
                        accent = HoloCyan
                    )

                    val presets = listOf(
                        "Optimize Z-Gate & Wi-Fi",
                        "Best Globe LiFi bulb placement",
                        "Tune LED location guidance"
                    )
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(presets) { preset ->
                            FilterChip(
                                selected = false,
                                onClick = { onSendCopilotMessage(preset) },
                                label = { Text(preset, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }

                    chatMessages.forEach { msg ->
                        Surface(
                            color = if (msg.isUser) HoloCyan.copy(alpha = 0.15f) else SpaceCardElevated,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = if (msg.isUser) "YOU" else "GEMINI 3.8 FLASH",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (msg.isUser) HoloCyan else IndigoAi
                                )
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    text = msg.text.ifBlank { "..." },
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextPrimary
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = copilotInput,
                            onValueChange = { copilotInput = it },
                            placeholder = { Text("Ask about RF, LiFi, Globe Suite...") },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("copilot_input")
                        )
                        IconButton(
                            onClick = {
                                onSendCopilotMessage(copilotInput)
                                copilotInput = ""
                            },
                            enabled = copilotInput.isNotBlank(),
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("copilot_send_btn")
                        ) {
                            Icon(
                                Icons.AutoMirrored.Filled.Send,
                                contentDescription = "Send question",
                                tint = HoloCyan
                            )
                        }
                    }
                }
            }
        }

        if (insightsHistory.isNotEmpty()) {
            item {
                SectionHeader(
                    title = "Saved Insight Log",
                    subtitle = "Recent Gemini spatial audits",
                    icon = Icons.Default.Security
                )
            }
            items(insightsHistory, key = { it.id }) { item ->
                Surface(
                    color = SpaceCard,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, SpaceBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(item.title, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                            StatusPillBadge("${item.healthScore}/100", ZGateEmerald)
                        }
                        Text(item.summary, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                    }
                }
            }
        }
    }
}

@Composable
private fun AiAuditResultCard(result: AiAuditResult) {
    val scoreColor = when {
        result.healthScore >= 80 -> ZGateEmerald
        result.healthScore >= 55 -> AmberCalibration
        else -> CoralAlert
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Spatial & RF Health Score",
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimary
            )
            StatusPillBadge("${result.healthScore} / 100", scoreColor)
        }
        AuditSectionRow("Spatial Z-Gate Summary", result.spatialSummary, HoloCyan)
        AuditSectionRow("Wi-Fi Optimization", result.wifiOptimization, ZGateEmerald)
        AuditSectionRow("LiFi & LED Light Guidance", result.lifiAndLightGuidance, AmberCalibration)
        AuditSectionRow("Security & Interference", result.securityAlert, CoralAlert)
    }
}

@Composable
private fun AuditSectionRow(
    label: String,
    body: String,
    accent: androidx.compose.ui.graphics.Color
) {
    Surface(
        color = SpaceCardElevated,
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(
                label.uppercase(),
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = accent
            )
            Text(body, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
        }
    }
}
