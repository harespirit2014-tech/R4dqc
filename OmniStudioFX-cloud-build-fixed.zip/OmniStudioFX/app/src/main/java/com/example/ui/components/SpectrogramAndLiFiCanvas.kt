package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.example.data.model.GuidanceState
import com.example.data.model.GuidanceZone
import com.example.data.model.LiFiStatus
import com.example.data.model.TelemetryPoint
import com.example.ui.theme.AmberCalibration
import com.example.ui.theme.CoralAlert
import com.example.ui.theme.DeepSpaceBg
import com.example.ui.theme.HoloCyan
import com.example.ui.theme.IndigoAi
import com.example.ui.theme.SpaceBorder
import com.example.ui.theme.SpaceCard
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.ZGateEmerald
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun OfdmDopplerSpectrogram(
    telemetrySeries: List<TelemetryPoint>,
    motionVariance: Float,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "ofdm_anim")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 6.283f,
        animationSpec = infiniteRepeatable(
            animation = tween(3200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "ofdm_phase"
    )
    val latestPerturbation = telemetrySeries.lastOrNull()?.dopplerPerturbationDb2 ?: (motionVariance * 2.1f)

    Column(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(SpaceCard)
            .border(1.dp, SpaceBorder, RoundedCornerShape(14.dp))
            .padding(12.dp)
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(64.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF040914))
        ) {
            val cols = 48
            val rows = 10
            val cellW = size.width / cols
            val cellH = size.height / rows
            val amp = (0.4f + latestPerturbation * 0.14f).coerceIn(0.3f, 1.4f)

            for (c in 0 until cols) {
                val xNorm = c / cols.toFloat()
                val ridgeCenter = 0.5f + 0.34f * sin(xNorm * 8.5f - phase) * amp
                val ridgeCenter2 = 0.5f + 0.28f * cos(xNorm * 6.2f + phase * 0.7f)
                for (r in 0 until rows) {
                    val yNorm = r / rows.toFloat()
                    val d1 = kotlin.math.abs(yNorm - ridgeCenter)
                    val d2 = kotlin.math.abs(yNorm - ridgeCenter2)
                    val energy = (1f - minOf(d1, d2) * 3.2f).coerceIn(0f, 1f)
                    val color = when {
                        energy > 0.78f -> CoralAlert
                        energy > 0.55f -> AmberCalibration
                        energy > 0.32f -> ZGateEmerald
                        energy > 0.12f -> HoloCyan.copy(alpha = 0.7f)
                        else -> Color(0xFF091B3A)
                    }
                    drawRect(
                        color = color,
                        topLeft = Offset(c * cellW, r * cellH),
                        size = Size(cellW + 0.5f, cellH + 0.5f)
                    )
                }
            }
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "64 OFDM Subcarriers + Real-Time Doppler Trail",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
            Text(
                text = "Δ ${"%.2f".format(latestPerturbation)} dB²",
                style = MaterialTheme.typography.labelMedium,
                color = AmberCalibration
            )
        }
    }
}

@Composable
fun LiFiEyeDiagramAndConstellation(
    lifi: LiFiStatus,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "lifi_eye")
    val drift by transition.animateFloat(
        initialValue = 0f,
        targetValue = 6.283f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "eye_drift"
    )

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF050A14))
            .border(1.dp, SpaceBorder, RoundedCornerShape(14.dp))
            .padding(12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Left: Eye Diagram
        Canvas(
            modifier = Modifier
                .weight(1.7f)
                .height(84.dp)
        ) {
            val w = size.width
            val h = size.height
            val midY = h * 0.5f
            val ampFactor = if (lifi.isRxActive || lifi.isTxActive) {
                (0.32f + (lifi.currentLux / 600f).coerceIn(0.05f, 0.48f))
            } else {
                0.28f
            }

            // Threshold center line
            drawLine(
                color = SpaceBorder,
                start = Offset(0f, midY),
                end = Offset(w, midY),
                strokeWidth = 1f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
            )

            val traceColors = listOf(HoloCyan, ZGateEmerald, HoloCyan.copy(alpha = 0.6f))
            traceColors.forEachIndexed { idx, col ->
                val path = Path()
                val steps = 40
                for (i in 0..steps) {
                    val t = i / steps.toFloat()
                    val x = t * w
                    val sign = if (idx % 2 == 0) 1f else -1f
                    val jitter = if (lifi.isRxActive) sin(t * 14f + drift + idx) * 2.5f else 0f
                    val y = midY + sign * sin(t * Math.PI * 2.0 + idx * 0.45).toFloat() * (h * ampFactor) + jitter
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                drawPath(path = path, color = col, style = Stroke(width = 2f, cap = StrokeCap.Round))
            }
        }

        // Right: Constellation & Decision Threshold
        Canvas(
            modifier = Modifier
                .weight(1f)
                .height(84.dp)
        ) {
            val center = Offset(size.width * 0.5f, size.height * 0.5f)
            val radius = minOf(size.width, size.height) * 0.42f
            drawCircle(
                color = SpaceBorder,
                radius = radius,
                center = center,
                style = Stroke(width = 1.5f)
            )
            drawLine(
                color = SpaceBorder.copy(alpha = 0.6f),
                start = Offset(center.x, center.y - radius),
                end = Offset(center.x, center.y + radius),
                strokeWidth = 1f
            )
            val separation = radius * (if (lifi.isRxActive || lifi.isTxActive) 0.62f else 0.45f)
            val jitter = if (lifi.isRxActive) sin(drift * 2f) * 2.5f else 0f
            drawCircle(
                color = if (lifi.isTorchLit) AmberCalibration else HoloCyan,
                radius = 5.5f,
                center = Offset(center.x - separation + jitter, center.y)
            )
            drawCircle(
                color = ZGateEmerald,
                radius = 5.5f,
                center = Offset(center.x + separation - jitter, center.y)
            )
        }
    }
}

@Composable
fun TelemetryTrendChart(
    points: List<TelemetryPoint>,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(SpaceCard)
            .border(1.dp, SpaceBorder, RoundedCornerShape(16.dp))
            .padding(14.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Live RF RSSI & Doppler Stream",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "${points.size} samples",
                    style = MaterialTheme.typography.labelSmall,
                    color = HoloCyan
                )
            }
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
            ) {
                if (points.size < 2) return@Canvas
                val w = size.width
                val h = size.height

                // Horizontal guides
                for (i in 1..3) {
                    val y = h * (i / 4f)
                    drawLine(
                        color = SpaceBorder.copy(alpha = 0.5f),
                        start = Offset(0f, y),
                        end = Offset(w, y),
                        strokeWidth = 1f
                    )
                }

                val rssiPath = Path()
                val dopplerPath = Path()
                points.forEachIndexed { idx, pt ->
                    val x = (idx / (points.size - 1).toFloat()) * w
                    // RSSI -95..-30 mapped to h..0
                    val rssiNorm = ((pt.avgRssiDbm + 95f) / 65f).coerceIn(0.05f, 0.95f)
                    val ry = h * (1f - rssiNorm)
                    if (idx == 0) rssiPath.moveTo(x, ry) else rssiPath.lineTo(x, ry)

                    val dopNorm = (pt.dopplerPerturbationDb2 / 8f).coerceIn(0.05f, 0.95f)
                    val dy = h * (1f - dopNorm)
                    if (idx == 0) dopplerPath.moveTo(x, dy) else dopplerPath.lineTo(x, dy)
                }

                drawPath(
                    path = rssiPath,
                    color = HoloCyan,
                    style = Stroke(width = 3f, cap = StrokeCap.Round)
                )
                drawPath(
                    path = dopplerPath,
                    color = IndigoAi,
                    style = Stroke(width = 2.5f, cap = StrokeCap.Round)
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Text("● Avg Wi-Fi RSSI", style = MaterialTheme.typography.labelSmall, color = HoloCyan)
                Text("● Doppler Perturbation", style = MaterialTheme.typography.labelSmall, color = IndigoAi)
            }
        }
    }
}

@Composable
fun CompassGuidanceRadar(
    guidance: GuidanceState,
    modifier: Modifier = Modifier
) {
    val zoneColor = when (guidance.guidanceZone) {
        GuidanceZone.STANDBY -> TextSecondary
        GuidanceZone.SEARCHING -> AmberCalibration
        GuidanceZone.APPROACHING -> HoloCyan
        GuidanceZone.LOCKED_ON -> ZGateEmerald
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.radialGradient(
                    colors = listOf(zoneColor.copy(alpha = 0.16f), DeepSpaceBg)
                )
            )
            .border(1.dp, zoneColor.copy(alpha = 0.45f), RoundedCornerShape(20.dp)),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize().padding(14.dp)) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val maxR = minOf(size.width, size.height) * 0.44f

            // Concentric radar rings
            listOf(1f, 0.68f, 0.36f).forEach { factor ->
                drawCircle(
                    color = zoneColor.copy(alpha = 0.25f),
                    radius = maxR * factor,
                    center = center,
                    style = Stroke(width = 1.5f)
                )
            }

            // Torch pulse aura when hardware LED is active
            if (guidance.isTorchActive) {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(zoneColor.copy(alpha = 0.5f), Color.Transparent),
                        center = center,
                        radius = maxR * 0.62f
                    ),
                    radius = maxR * 0.62f,
                    center = center
                )
            }

            // Relative bearing arrow (targetBearing - deviceAzimuth)
            val relAngleDeg = guidance.targetBearingDeg - guidance.deviceAzimuthDeg
            val rad = Math.toRadians((relAngleDeg - 90f).toDouble())
            val tip = Offset(
                x = center.x + (cos(rad) * maxR * 0.85f).toFloat(),
                y = center.y + (sin(rad) * maxR * 0.85f).toFloat()
            )
            drawLine(
                color = zoneColor,
                start = center,
                end = tip,
                strokeWidth = 5f,
                cap = StrokeCap.Round
            )
            drawCircle(color = zoneColor, radius = 9f, center = tip)
            drawCircle(color = Color.White, radius = 5f, center = center)
        }
    }
}
