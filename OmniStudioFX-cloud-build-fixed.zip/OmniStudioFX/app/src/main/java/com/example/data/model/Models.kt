package com.example.data.model

enum class FloorLevel(
    val index: Int,
    val label: String,
    val shortCode: String,
    val elevationMeters: Float
) {
    BASEMENT(0, "Basement (-2.8m)", "BSMT", -2.8f),
    GROUND(1, "Ground Floor (0.0m)", "GND", 0.0f),
    UPPER(2, "Upper Floor (+3.0m)", "UPR", 3.0f);

    companion object {
        fun fromIndex(idx: Int): FloorLevel = entries.firstOrNull { it.index == idx } ?: BASEMENT
    }
}

enum class SceneViewMode(val label: String) {
    ACTIVE_FLOOR("3D FX Active Floor"),
    FULL_HOUSE_3D("Full 3D House (3 Floors)"),
    PLAN_EDITOR("Plan Editor (Rooms/AP)")
}

data class SpatialRoom(
    val id: Long = 0L,
    val name: String,
    val floorIndex: Int,
    val x: Float,
    val y: Float,
    val width: Float,
    val depth: Float,
    val hasAp: Boolean = false,
    val cloudId: String = ""
)

data class WifiNetworkNode(
    val ssid: String,
    val bssid: String,
    val rssiDbm: Int,
    val frequencyMhz: Int,
    val isRttCapable: Boolean,
    val estimatedDistanceM: Float,
    val floorGuess: Int,
    val aoaDeg: Int,
    val zAttenuationDb: Float,
    val isRejectedByZGate: Boolean,
    val isRogueSuspect: Boolean = false
)

data class GlobeBulb(
    val id: Long = 0L,
    val name: String,
    val floorIndex: Int,
    val roomName: String,
    val isOn: Boolean,
    val brightnessPct: Int,
    val colorTempKelvin: Int = 4000,
    val lifiSynced: Boolean = false,
    val lastPulseMs: Long = 0L,
    val cloudId: String = ""
)

data class TelemetryPoint(
    val timestampMs: Long,
    val pressureHpa: Float?,
    val ambientLux: Float?,
    val avgRssiDbm: Float,
    val dopplerPerturbationDb2: Float,
    val locationAccuracyM: Float?
)

data class AiAuditResult(
    val healthScore: Int,
    val spatialSummary: String,
    val wifiOptimization: String,
    val lifiAndLightGuidance: String,
    val securityAlert: String,
    val recommendedAlertTitle: String,
    val recommendedAlertBody: String
)

data class AiInsightRecord(
    val id: Long = 0L,
    val title: String,
    val summary: String,
    val category: String,
    val healthScore: Int,
    val timestampMs: Long,
    val cloudId: String = ""
)

data class GuidanceState(
    val isGuiding: Boolean = false,
    val targetName: String = "Globe Basement Hub",
    val targetFloor: Int = 0,
    val targetLat: Double? = null,
    val targetLon: Double? = null,
    val currentLat: Double? = null,
    val currentLon: Double? = null,
    val locationAccuracyM: Float? = null,
    val distanceMeters: Float? = null,
    val targetBearingDeg: Float = 0f,
    val deviceAzimuthDeg: Float = 0f,
    val alignmentErrorDeg: Float = 0f,
    val kalmanGain: Float = 0.35f,
    val ledPulseHz: Float = 0f,
    val guidanceZone: GuidanceZone = GuidanceZone.STANDBY,
    val isTorchActive: Boolean = false,
    val hasLocationPermission: Boolean = false
)

enum class GuidanceZone(val label: String) {
    STANDBY("Standby"),
    SEARCHING("Searching Signal"),
    APPROACHING("Approaching Vector"),
    LOCKED_ON("Target Aligned / Locked")
}

data class LiFiStatus(
    val isTxActive: Boolean = false,
    val isRxActive: Boolean = false,
    val isTorchLit: Boolean = false,
    val hasHardwareFlash: Boolean = true,
    val hasLightSensor: Boolean = true,
    val currentLux: Float = 0f,
    val estimatedBitrateKbps: Int = 0,
    val snrDb: Float = 0f,
    val activeFrameHex: String = "0xA5-GLOBE-SYNC",
    val rxStatusText: String = "RX: Ready"
)

data class SensorStatus(
    val hasBarometer: Boolean = false,
    val pressureHpa: Float? = null,
    val relativeAltitudeM: Float = 0f,
    val hasLightSensor: Boolean = false,
    val ambientLux: Float? = null,
    val azimuthDeg: Float = 0f,
    val motionVariance: Float = 0.08f
)

data class ChatMessage(
    val id: String,
    val isUser: Boolean,
    val text: String,
    val isStreaming: Boolean = false
)
