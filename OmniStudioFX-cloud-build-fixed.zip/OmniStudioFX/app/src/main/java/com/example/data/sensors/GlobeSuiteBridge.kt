package com.example.data.sensors

import android.content.Context
import android.content.Intent
import android.net.Uri

data class GlobeLaunchResult(
    val launchedInstalledApp: Boolean,
    val message: String
)

class GlobeSuiteBridge(private val context: Context) {
    companion object {
        private val CANDIDATE_PACKAGES = listOf(
            "com.globe.electric.suite",
            "com.tuya.smartlife",
            "com.tuya.smart"
        )
        private const val GLOBE_PLAY_URL =
            "https://play.google.com/store/apps/details?id=com.globe.electric.suite"
    }

    fun findInstalledGlobePackage(): String? {
        val pm = context.packageManager
        return CANDIDATE_PACKAGES.firstOrNull { pkg ->
            pm.getLaunchIntentForPackage(pkg) != null
        }
    }

    fun openGlobeSuiteApp(): GlobeLaunchResult {
        val pm = context.packageManager
        val installedPkg = findInstalledGlobePackage()
        if (installedPkg != null) {
            val launchIntent = pm.getLaunchIntentForPackage(installedPkg)?.apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (launchIntent != null) {
                context.startActivity(launchIntent)
                return GlobeLaunchResult(
                    launchedInstalledApp = true,
                    message = "Opened $installedPkg directly on device."
                )
            }
        }

        // Graceful fallback to Google Play Store listing for Globe Suite
        return try {
            val storeIntent = Intent(Intent.ACTION_VIEW, Uri.parse(GLOBE_PLAY_URL)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(storeIntent)
            GlobeLaunchResult(
                launchedInstalledApp = false,
                message = "Globe Suite app not installed; opened Play Store listing."
            )
        } catch (_: Exception) {
            GlobeLaunchResult(
                launchedInstalledApp = false,
                message = "Unable to open Globe Suite or Play Store on this device."
            )
        }
    }

    fun shareLiFiSceneToGlobe(sceneSummary: String) {
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "OmniStudio FX • Globe Suite LiFi Sync")
            putExtra(Intent.EXTRA_TEXT, sceneSummary)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val chooser = Intent.createChooser(shareIntent, "Send LiFi Scene Profile").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    }
}
