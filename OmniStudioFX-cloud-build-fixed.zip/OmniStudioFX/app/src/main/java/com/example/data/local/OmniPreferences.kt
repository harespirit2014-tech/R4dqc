package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.omniDataStore: DataStore<Preferences> by preferencesDataStore(name = "omnistudio_prefs")

data class UserSettings(
    val selectedFloorIndex: Int = 0,
    val zGateStrict: Boolean = true,
    val slabThresholdDb: Float = -15.5f,
    val autoAiNotifications: Boolean = true,
    val globeAccountEmail: String = "",
    val globeLinked: Boolean = false
)

class OmniPreferences(private val context: Context) {
    private object Keys {
        val SELECTED_FLOOR = intPreferencesKey("selected_floor")
        val ZGATE_STRICT = booleanPreferencesKey("zgate_strict")
        val SLAB_THRESHOLD = floatPreferencesKey("slab_threshold_db")
        val AUTO_AI_NOTIFY = booleanPreferencesKey("auto_ai_notify")
        val GLOBE_EMAIL = stringPreferencesKey("globe_email")
        val GLOBE_LINKED = booleanPreferencesKey("globe_linked")
    }

    val settingsFlow: Flow<UserSettings> = context.omniDataStore.data.map { prefs ->
        UserSettings(
            selectedFloorIndex = prefs[Keys.SELECTED_FLOOR] ?: 0,
            zGateStrict = prefs[Keys.ZGATE_STRICT] ?: true,
            slabThresholdDb = prefs[Keys.SLAB_THRESHOLD] ?: -15.5f,
            autoAiNotifications = prefs[Keys.AUTO_AI_NOTIFY] ?: true,
            globeAccountEmail = prefs[Keys.GLOBE_EMAIL].orEmpty(),
            globeLinked = prefs[Keys.GLOBE_LINKED] ?: false
        )
    }

    suspend fun setSelectedFloor(index: Int) {
        context.omniDataStore.edit { it[Keys.SELECTED_FLOOR] = index }
    }

    suspend fun setZGateStrict(strict: Boolean) {
        context.omniDataStore.edit { it[Keys.ZGATE_STRICT] = strict }
    }

    suspend fun setSlabThresholdDb(db: Float) {
        context.omniDataStore.edit { it[Keys.SLAB_THRESHOLD] = db }
    }

    suspend fun setAutoAiNotifications(enabled: Boolean) {
        context.omniDataStore.edit { it[Keys.AUTO_AI_NOTIFY] = enabled }
    }

    suspend fun setGlobeLink(email: String, linked: Boolean) {
        context.omniDataStore.edit {
            it[Keys.GLOBE_EMAIL] = email
            it[Keys.GLOBE_LINKED] = linked
        }
    }
}
