package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DeepSpaceBg = Color(0xFF060A13)
val SpaceSurface = Color(0xFF0B1220)
val SpaceCard = Color(0xFF101A2E)
val SpaceCardElevated = Color(0xFF16233B)
val SpaceBorder = Color(0xFF223354)

val HoloCyan = Color(0xFF38BDF8)
val HoloCyanDim = Color(0xFF0E7490)
val ZGateEmerald = Color(0xFF10B981)
val ZGateEmeraldBg = Color(0xFF064E3B)
val AmberCalibration = Color(0xFFF59E0B)
val AmberBg = Color(0xFF451A03)
val CoralAlert = Color(0xFFF43F5E)
val CoralBg = Color(0xFF4C0519)
val IndigoAi = Color(0xFF818CF8)
val VioletGlow = Color(0xFFA78BFA)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
