package com.example.data.ai

import android.util.Log
import com.example.data.model.AiAuditResult
import com.example.data.model.FloorLevel
import com.example.data.model.GlobeBulb
import com.example.data.model.GuidanceState
import com.example.data.model.LiFiStatus
import com.example.data.model.SensorStatus
import com.example.data.model.SpatialRoom
import com.example.data.model.WifiNetworkNode
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

private const val TAG = "GeminiAnalyticsRepo"

class GeminiAnalyticsRepository {

    private val auditSchema = Schema.obj(
        properties = mapOf(
            "healthScore" to Schema.integer(description = "Overall spatial RF, LiFi, and lighting health score from 0 to 100"),
            "spatialSummary" to Schema.string(description = "Concise 1-2 sentence real-time summary of floor Z-Gate isolation, barometer, and room layout"),
            "wifiOptimization" to Schema.string(description = "Actionable Wi-Fi 5/6GHz, RTT, or AP placement advice based on current scan"),
            "lifiAndLightGuidance" to Schema.string(description = "Recommendation for Globe Suite smart bulbs, LiFi optical link SNR, and location-guided LED routing"),
            "securityAlert" to Schema.string(description = "Rogue AP or RF interference check based on live scanned networks"),
            "recommendedAlertTitle" to Schema.string(description = "Short push notification title under 45 chars"),
            "recommendedAlertBody" to Schema.string(description = "Actionable push notification message under 110 chars")
        )
    )

    private val auditModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = auditSchema
                temperature = 0.3f
            },
            systemInstruction = content {
                text(
                    "You are OmniStudio FX Core AI, an expert spatial RF engineer, Wi-Fi 802.11mc RTT analyst, " +
                        "optical LiFi & Globe Suite smart-lighting architect, and location-guided LED navigation specialist. " +
                        "Analyze live Android sensor, Wi-Fi, location, and Globe Suite telemetry concisely and accurately."
                )
            }
        )
    }

    private val chatModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            systemInstruction = content {
                text(
                    "You are OmniStudio FX Copilot. Answer user questions using the provided real-time " +
                        "telemetry context (3D floor Z-Gate, Wi-Fi RSSI/RTT, Globe Suite smart bulbs, LiFi Lux RX/TX, " +
                        "and location LED guidance). Keep answers practical, technical, and concise."
                )
            }
        )
    }

    suspend fun runSpatialAudit(
        activeFloor: FloorLevel,
        zGateStrict: Boolean,
        slabThresholdDb: Float,
        sensors: SensorStatus,
        wifiNodes: List<WifiNetworkNode>,
        rooms: List<SpatialRoom>,
        bulbs: List<GlobeBulb>,
        lifi: LiFiStatus,
        guidance: GuidanceState
    ): AiAuditResult {
        val telemetryPrompt = buildTelemetryContext(
            activeFloor, zGateStrict, slabThresholdDb, sensors, wifiNodes, rooms, bulbs, lifi, guidance
        ) + "\nGenerate a comprehensive real-time spatial, Wi-Fi, LiFi, Globe Suite, and LED guidance audit."

        try {
            val response = withTimeout(60_000L) {
                auditModel.generateContent(telemetryPrompt)
            }
            val rawJson = response.text ?: throw IllegalStateException("Gemini returned an empty response.")
            val json = JSONObject(rawJson)
            return AiAuditResult(
                healthScore = json.optInt("healthScore", 82).coerceIn(0, 100),
                spatialSummary = json.getString("spatialSummary"),
                wifiOptimization = json.getString("wifiOptimization"),
                lifiAndLightGuidance = json.getString("lifiAndLightGuidance"),
                securityAlert = json.getString("securityAlert"),
                recommendedAlertTitle = json.getString("recommendedAlertTitle"),
                recommendedAlertBody = json.getString("recommendedAlertBody")
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "runSpatialAudit failed", e)
            throw e
        }
    }

    fun streamCopilotAnswer(
        question: String,
        telemetryContext: String
    ): Flow<String> = flow {
        val fullPrompt = "LIVE TELEMETRY CONTEXT:\n$telemetryContext\n\nUSER QUESTION:\n$question"
        val accumulated = StringBuilder()
        withTimeout(60_000L) {
            chatModel.generateContentStream(fullPrompt).collect { chunk ->
                val part = chunk.text.orEmpty()
                if (part.isNotEmpty()) {
                    accumulated.append(part)
                    emit(accumulated.toString())
                }
            }
        }
    }

    fun buildTelemetryContext(
        activeFloor: FloorLevel,
        zGateStrict: Boolean,
        slabThresholdDb: Float,
        sensors: SensorStatus,
        wifiNodes: List<WifiNetworkNode>,
        rooms: List<SpatialRoom>,
        bulbs: List<GlobeBulb>,
        lifi: LiFiStatus,
        guidance: GuidanceState
    ): String {
        val sameFloorCount = wifiNodes.count { !it.isRejectedByZGate }
        val rejectedCount = wifiNodes.count { it.isRejectedByZGate }
        val rogueCount = wifiNodes.count { it.isRogueSuspect }
        val topAps = wifiNodes.take(5).joinToString("; ") {
            "${it.ssid} (${it.rssiDbm} dBm, ${it.frequencyMhz} MHz, ~${"%.1f".format(it.estimatedDistanceM)}m, RTT=${it.isRttCapable}, ZGateRejected=${it.isRejectedByZGate})"
        }.ifBlank { "No live APs scanned yet" }

        val activeBulbs = bulbs.count { it.isOn }
        val bulbSummary = bulbs.joinToString("; ") {
            "${it.name} [Floor ${it.floorIndex}, On=${it.isOn}, ${it.brightnessPct}%, LiFiSync=${it.lifiSynced}]"
        }

        return """
            - Active Floor: ${activeFloor.label}, Z-Gate Strict=$zGateStrict, Slab Threshold=${slabThresholdDb} dB
            - Barometer: ${sensors.pressureHpa?.let { "%.1f hPa (relAlt %.2fm)".format(it, sensors.relativeAltitudeM) } ?: "Not present on device"}
            - Ambient Light (Lux): ${sensors.ambientLux?.let { "%.1f lx".format(it) } ?: "Unavailable"} | Motion Variance: ${"%.2f".format(sensors.motionVariance)}
            - Mapped Rooms (${rooms.size} total): ${rooms.count { it.floorIndex == activeFloor.index }} on active floor
            - Wi-Fi Scan (${wifiNodes.size} APs): $sameFloorCount accepted, $rejectedCount Z-Gate rejected, $rogueCount open/rogue suspects. Top APs: $topAps
            - Globe Suite Bulbs ($activeBulbs/${bulbs.size} ON): $bulbSummary
            - LiFi Link: TX=${lifi.isTxActive}, RX=${lifi.isRxActive}, SNR=${"%.1f".format(lifi.snrDb)} dB, Bitrate=${lifi.estimatedBitrateKbps} kbps
            - Location LED Guidance: Active=${guidance.isGuiding}, Target=${guidance.targetName}, Distance=${guidance.distanceMeters?.let { "%.1fm".format(it) } ?: "N/A"}, Bearing=${guidance.targetBearingDeg.toInt()} deg, Azimuth=${guidance.deviceAzimuthDeg.toInt()} deg, AlignmentError=${guidance.alignmentErrorDeg.toInt()} deg, LED Pulse=${"%.1f".format(guidance.ledPulseHz)} Hz, Zone=${guidance.guidanceZone.label}
        """.trimIndent()
    }
}
