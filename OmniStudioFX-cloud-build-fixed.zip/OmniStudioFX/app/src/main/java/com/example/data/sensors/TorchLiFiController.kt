package com.example.data.sensors

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class TorchLiFiController(context: Context) {
    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val torchCameraId: String? = findFlashCameraId()

    private val _hasFlashHardware = MutableStateFlow(torchCameraId != null)
    val hasFlashHardware: StateFlow<Boolean> = _hasFlashHardware.asStateFlow()

    private val _isTorchLit = MutableStateFlow(false)
    val isTorchLit: StateFlow<Boolean> = _isTorchLit.asStateFlow()

    private var pulseJob: Job? = null

    private val torchCallback = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
            if (cameraId == torchCameraId) {
                _isTorchLit.value = enabled
            }
        }
    }

    init {
        try {
            cameraManager.registerTorchCallback(torchCallback, Handler(Looper.getMainLooper()))
        } catch (_: Exception) {
            // Safe fallback
        }
    }

    private fun findFlashCameraId(): String? {
        return try {
            cameraManager.cameraIdList.firstOrNull { id ->
                val chars = cameraManager.getCameraCharacteristics(id)
                val hasFlash = chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                val facing = chars.get(CameraCharacteristics.LENS_FACING)
                hasFlash && facing == CameraCharacteristics.LENS_FACING_BACK
            } ?: cameraManager.cameraIdList.firstOrNull { id ->
                cameraManager.getCameraCharacteristics(id)
                    .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
        } catch (_: Exception) {
            null
        }
    }

    fun setTorchImmediate(on: Boolean) {
        _isTorchLit.value = on
        val id = torchCameraId ?: return
        try {
            cameraManager.setTorchMode(id, on)
        } catch (_: Exception) {
            // Hardware busy or unavailable
        }
    }

    /**
     * Transmits an optical OOK / Manchester frame via the hardware LED flashlight
     * (e.g., Globe Suite Sync frame or Floor Beacon) while mirroring state to UI.
     */
    fun transmitLiFiFrame(
        scope: CoroutineScope,
        bits: String = "1010010111001010",
        bitPeriodMs: Long = 90L,
        repeatCount: Int = 3,
        onComplete: () -> Unit = {}
    ) {
        stopModulation()
        pulseJob = scope.launch(Dispatchers.Default) {
            try {
                repeat(repeatCount) {
                    for (ch in bits) {
                        if (!isActive) return@launch
                        setTorchImmediate(ch == '1')
                        delay(bitPeriodMs)
                    }
                    setTorchImmediate(false)
                    delay(bitPeriodMs * 2)
                }
            } finally {
                setTorchImmediate(false)
                onComplete()
            }
        }
    }

    /**
     * Continuously modulates the physical LED flashlight at [frequencyProvider] Hz
     * driven by the real-time Location Guidance algorithm.
     */
    fun startGuidanceLedModulation(
        scope: CoroutineScope,
        frequencyProvider: () -> Float
    ) {
        stopModulation()
        pulseJob = scope.launch(Dispatchers.Default) {
            try {
                var phase = false
                while (isActive) {
                    val hz = frequencyProvider()
                    if (hz <= 0.1f) {
                        setTorchImmediate(false)
                        delay(200L)
                    } else {
                        phase = !phase
                        setTorchImmediate(phase)
                        val halfPeriodMs = (500f / hz.coerceIn(0.5f, 12f)).toLong().coerceAtLeast(40L)
                        delay(halfPeriodMs)
                    }
                }
            } finally {
                setTorchImmediate(false)
            }
        }
    }

    fun stopModulation() {
        pulseJob?.cancel()
        pulseJob = null
        setTorchImmediate(false)
    }

    fun release() {
        stopModulation()
        try {
            cameraManager.unregisterTorchCallback(torchCallback)
        } catch (_: Exception) {
        }
    }
}
