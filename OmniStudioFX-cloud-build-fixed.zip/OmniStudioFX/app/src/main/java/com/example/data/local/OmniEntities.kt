package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.AiInsightRecord
import com.example.data.model.GlobeBulb
import com.example.data.model.SpatialRoom

@Entity(tableName = "spatial_rooms")
data class SpatialRoomEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val name: String,
    val floorIndex: Int,
    val x: Float,
    val y: Float,
    val width: Float,
    val depth: Float,
    val hasAp: Boolean
) {
    fun toDomain() = SpatialRoom(id, name, floorIndex, x, y, width, depth, hasAp)
}

fun SpatialRoom.toEntity() = SpatialRoomEntity(id, name, floorIndex, x, y, width, depth, hasAp)

@Entity(tableName = "globe_bulbs")
data class GlobeBulbEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val name: String,
    val floorIndex: Int,
    val roomName: String,
    val isOn: Boolean,
    val brightnessPct: Int,
    val colorTempKelvin: Int,
    val lifiSynced: Boolean,
    val lastPulseMs: Long
) {
    fun toDomain() = GlobeBulb(
        id, name, floorIndex, roomName, isOn, brightnessPct, colorTempKelvin, lifiSynced, lastPulseMs
    )
}

fun GlobeBulb.toEntity() = GlobeBulbEntity(
    id, name, floorIndex, roomName, isOn, brightnessPct, colorTempKelvin, lifiSynced, lastPulseMs
)

@Entity(tableName = "ai_insights")
data class AiInsightEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val title: String,
    val summary: String,
    val category: String,
    val healthScore: Int,
    val timestampMs: Long
) {
    fun toDomain() = AiInsightRecord(id, title, summary, category, healthScore, timestampMs)
}
