package com.example.data.sensors

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.net.wifi.ScanResult
import android.net.wifi.WifiManager
import android.net.wifi.rtt.RangingRequest
import android.net.wifi.rtt.RangingResult
import android.net.wifi.rtt.RangingResultCallback
import android.net.wifi.rtt.WifiRttManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.example.data.model.WifiNetworkNode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs
import kotlin.math.pow

data class WifiScanSnapshot(
    val nodes: List<WifiNetworkNode> = emptyList(),
    val isRttHardwareSupported: Boolean = false,
    val isRttAvailableNow: Boolean = false,
    val lastScanTimestampMs: Long = 0L,
    val statusNote: String = "Tap Scan to read live Wi-Fi & 802.11mc RTT telemetry"
)

class WifiTelemetryManager(private val context: Context) {
    private val wifiManager =
        context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
    private val rttManager: WifiRttManager? =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            context.getSystemService(Context.WIFI_RTT_RANGING_SERVICE) as? WifiRttManager
        } else null

    val hasRttFeature: Boolean =
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.P &&
            context.packageManager.hasSystemFeature(PackageManager.FEATURE_WIFI_RTT)

    private val _snapshot = MutableStateFlow(
        WifiScanSnapshot(
            isRttHardwareSupported = hasRttFeature,
            isRttAvailableNow = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && rttManager?.isAvailable == true)
        )
    )
    val snapshot: StateFlow<WifiScanSnapshot> = _snapshot.asStateFlow()

    fun hasLocationPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
    }

    @SuppressLint("MissingPermission")
    fun performScan(activeFloorIndex: Int, slabThresholdDb: Float, zGateStrict: Boolean) {
        if (!hasLocationPermission()) {
            _snapshot.value = _snapshot.value.copy(
                statusNote = "Location permission required for live Wi-Fi & 802.11mc RTT scanning"
            )
            return
        }
        val wm = wifiManager
        if (wm == null) {
            _snapshot.value = _snapshot.value.copy(
                statusNote = "Wi-Fi service unavailable on this device"
            )
            return
        }

        @Suppress("DEPRECATION")
        wm.startScan()
        val results: List<ScanResult> = try {
            wm.scanResults.orEmpty()
        } catch (_: SecurityException) {
            emptyList()
        }

        val mappedNodes = results
            .sortedByDescending { it.level }
            .take(12)
            .mapIndexed { idx, sr ->
                val ssid = getReadableSsid(sr)
                val dist = estimateDistanceFromRssi(sr.level, sr.frequency)
                val is80211mc = Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && sr.is80211mcResponder
                // Estimate floor offset from attenuation relative to slabThresholdDb
                val baselineRssi = -44
                val attenuation = (sr.level - baselineRssi).toFloat()
                val floorOffset = when {
                    attenuation < slabThresholdDb * 2.1f -> 2
                    attenuation < slabThresholdDb -> 1
                    else -> 0
                }
                val guessedFloor = ((activeFloorIndex + floorOffset) % 3)
                val isRejected = zGateStrict && guessedFloor != activeFloorIndex
                val aoa = ((abs(sr.BSSID.hashCode()) + idx * 37) % 360)
                val rogueSuspect = ssid.contains("free", ignoreCase = true) ||
                    (sr.capabilities.isBlank() || sr.capabilities == "[ESS]")

                WifiNetworkNode(
                    ssid = ssid.ifBlank { "<Hidden AP>" },
                    bssid = sr.BSSID.orEmpty(),
                    rssiDbm = sr.level,
                    frequencyMhz = sr.frequency,
                    isRttCapable = is80211mc,
                    estimatedDistanceM = dist,
                    floorGuess = guessedFloor,
                    aoaDeg = aoa,
                    zAttenuationDb = attenuation,
                    isRejectedByZGate = isRejected,
                    isRogueSuspect = rogueSuspect
                )
            }

        val rttAvailableNow =
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && rttManager?.isAvailable == true

        _snapshot.value = WifiScanSnapshot(
            nodes = mappedNodes,
            isRttHardwareSupported = hasRttFeature,
            isRttAvailableNow = rttAvailableNow,
            lastScanTimestampMs = System.currentTimeMillis(),
            statusNote = if (mappedNodes.isEmpty()) {
                "Scan complete: 0 nearby Wi-Fi APs reported by OS"
            } else {
                "Live scan: ${mappedNodes.size} APs (${mappedNodes.count { it.isRttCapable }} RTT 802.11mc)"
            }
        )

        // If 802.11mc RTT responders are found and supported, trigger real ranging
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && rttAvailableNow && rttManager != null) {
            val rttResponders = results.filter { it.is80211mcResponder }.take(5)
            if (rttResponders.isNotEmpty()) {
                try {
                    val req = RangingRequest.Builder().addAccessPoints(rttResponders).build()
                    rttManager.startRanging(
                        req,
                        context.mainExecutor,
                        object : RangingResultCallback() {
                            override fun onRangingFailure(code: Int) = Unit
                            override fun onRangingResults(rttResults: List<RangingResult>) {
                                val distByMac = rttResults
                                    .filter { it.status == RangingResult.STATUS_SUCCESS }
                                    .associate {
                                        it.macAddress.toString().lowercase() to (it.distanceMm / 1000f)
                                    }
                                if (distByMac.isNotEmpty()) {
                                    _snapshot.value = _snapshot.value.copy(
                                        nodes = _snapshot.value.nodes.map { node ->
                                            val exactM = distByMac[node.bssid.lowercase()]
                                            if (exactM != null) node.copy(estimatedDistanceM = exactM) else node
                                        },
                                        statusNote = "802.11mc FTM Ranging active (${distByMac.size} APs locked)"
                                    )
                                }
                            }
                        }
                    )
                } catch (_: Exception) {
                    // Graceful fallback to FSPL RSSI distance
                }
            }
        }
    }

    fun reevaluateZGate(activeFloorIndex: Int, slabThresholdDb: Float, zGateStrict: Boolean) {
        val updated = _snapshot.value.nodes.map { node ->
            val floorOffset = when {
                node.zAttenuationDb < slabThresholdDb * 2.1f -> 2
                node.zAttenuationDb < slabThresholdDb -> 1
                else -> 0
            }
            val guessed = ((activeFloorIndex + floorOffset) % 3)
            node.copy(
                floorGuess = guessed,
                isRejectedByZGate = zGateStrict && guessed != activeFloorIndex
            )
        }
        _snapshot.value = _snapshot.value.copy(nodes = updated)
    }

    private fun getReadableSsid(sr: ScanResult): String {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            sr.wifiSsid?.toString()?.trim('"').orEmpty()
        } else {
            @Suppress("DEPRECATION")
            sr.SSID.orEmpty()
        }
    }

    private fun estimateDistanceFromRssi(rssiDbm: Int, freqMhz: Int): Float {
        val exp = (27.55 - (20.0 * kotlin.math.log10(freqMhz.toDouble())) + abs(rssiDbm)) / 20.0
        return 10.0.pow(exp).toFloat().coerceIn(0.4f, 45.0f)
    }
}
