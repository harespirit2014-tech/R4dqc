package com.example.data.sensors

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import com.example.data.model.SensorStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlin.math.abs
import kotlin.math.sqrt

class SensorTelemetryManager(context: Context) : SensorEventListener {
    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager

    private val pressureSensor: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_PRESSURE)
    private val lightSensor: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT)
    private val rotationSensor: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
    private val accelSensor: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION)
        ?: sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    private var baselinePressureHpa: Float? = null
    private val rotationMatrix = FloatArray(9)
    private val orientationAngles = FloatArray(3)
    private var smoothedVariance = 0.08f

    private val _sensorStatus = MutableStateFlow(
        SensorStatus(
            hasBarometer = pressureSensor != null,
            hasLightSensor = lightSensor != null
        )
    )
    val sensorStatus: StateFlow<SensorStatus> = _sensorStatus.asStateFlow()

    fun start() {
        pressureSensor?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
        lightSensor?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
        rotationSensor?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
        accelSensor?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
    }

    fun stop() {
        sensorManager.unregisterListener(this)
    }

    fun recalibrateBarometerBaseline() {
        baselinePressureHpa = _sensorStatus.value.pressureHpa
        _sensorStatus.update { it.copy(relativeAltitudeM = 0f) }
    }

    override fun onSensorChanged(event: SensorEvent) {
        when (event.sensor.type) {
            Sensor.TYPE_PRESSURE -> {
                val hpa = event.values[0]
                if (baselinePressureHpa == null) baselinePressureHpa = hpa
                val base = baselinePressureHpa ?: hpa
                val relAlt = SensorManager.getAltitude(base, hpa)
                _sensorStatus.update {
                    it.copy(
                        hasBarometer = true,
                        pressureHpa = hpa,
                        relativeAltitudeM = relAlt
                    )
                }
            }

            Sensor.TYPE_LIGHT -> {
                val lux = event.values[0].coerceAtLeast(0f)
                _sensorStatus.update {
                    it.copy(
                        hasLightSensor = true,
                        ambientLux = lux
                    )
                }
            }

            Sensor.TYPE_ROTATION_VECTOR -> {
                SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
                SensorManager.getOrientation(rotationMatrix, orientationAngles)
                val azimuthRad = orientationAngles[0]
                val azimuthDeg = ((Math.toDegrees(azimuthRad.toDouble()).toFloat()) + 360f) % 360f
                _sensorStatus.update { it.copy(azimuthDeg = azimuthDeg) }
            }

            Sensor.TYPE_LINEAR_ACCELERATION, Sensor.TYPE_ACCELEROMETER -> {
                val mag = sqrt(
                    event.values[0] * event.values[0] +
                        event.values[1] * event.values[1] +
                        event.values[2] * event.values[2]
                )
                val delta = if (event.sensor.type == Sensor.TYPE_ACCELEROMETER) {
                    abs(mag - SensorManager.GRAVITY_EARTH)
                } else {
                    mag
                }
                smoothedVariance = (smoothedVariance * 0.85f) + (delta.coerceIn(0f, 5f) * 0.15f)
                _sensorStatus.update { it.copy(motionVariance = smoothedVariance) }
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
}
