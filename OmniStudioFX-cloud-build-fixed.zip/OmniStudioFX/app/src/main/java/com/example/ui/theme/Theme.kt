package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

private val OmniDarkColorScheme = darkColorScheme(
    primary = HoloCyan,
    onPrimary = DeepSpaceBg,
    primaryContainer = HoloCyanDim,
    onPrimaryContainer = TextPrimary,
    secondary = ZGateEmerald,
    onSecondary = DeepSpaceBg,
    secondaryContainer = ZGateEmeraldBg,
    onSecondaryContainer = TextPrimary,
    tertiary = IndigoAi,
    onTertiary = DeepSpaceBg,
    tertiaryContainer = AmberBg,
    onTertiaryContainer = AmberCalibration,
    error = CoralAlert,
    onError = TextPrimary,
    errorContainer = CoralBg,
    onErrorContainer = CoralAlert,
    background = DeepSpaceBg,
    onBackground = TextPrimary,
    surface = SpaceSurface,
    onSurface = TextPrimary,
    surfaceVariant = SpaceCard,
    onSurfaceVariant = TextSecondary,
    outline = SpaceBorder,
    outlineVariant = SpaceCardElevated
)

val OmniShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp)
)

@Composable
fun OmniStudioTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = OmniDarkColorScheme,
        typography = OmniTypography,
        shapes = OmniShapes,
        content = content
    )
}
