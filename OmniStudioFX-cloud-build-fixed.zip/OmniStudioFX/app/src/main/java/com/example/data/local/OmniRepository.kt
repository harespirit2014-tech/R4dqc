package com.example.data.local

import com.example.data.model.AiInsightRecord
import com.example.data.model.GlobeBulb
import com.example.data.model.SpatialRoom
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class OmniRepository(private val dao: OmniDao) {
    val roomsFlow: Flow<List<SpatialRoom>> = dao.observeRooms().map { list ->
        list.map { it.toDomain() }
    }

    val bulbsFlow: Flow<List<GlobeBulb>> = dao.observeBulbs().map { list ->
        list.map { it.toDomain() }
    }

    val insightsFlow: Flow<List<AiInsightRecord>> = dao.observeInsights().map { list ->
        list.map { it.toDomain() }
    }

    suspend fun seedDefaultsIfEmpty() {
        if (dao.getRoomCount() == 0) {
            dao.insertRooms(
                listOf(
                    SpatialRoomEntity(name = "Tech Lab", floorIndex = 0, x = -2.2f, y = -1.6f, width = 2.4f, depth = 2.0f, hasAp = true),
                    SpatialRoomEntity(name = "Hallway BSMT", floorIndex = 0, x = 0.4f, y = -1.2f, width = 1.8f, depth = 2.4f, hasAp = false),
                    SpatialRoomEntity(name = "Living Room", floorIndex = 1, x = -2.0f, y = -1.5f, width = 2.8f, depth = 2.5f, hasAp = true),
                    SpatialRoomEntity(name = "Kitchen", floorIndex = 1, x = 1.0f, y = -1.5f, width = 1.8f, depth = 2.2f, hasAp = false),
                    SpatialRoomEntity(name = "Master Suite", floorIndex = 2, x = -1.8f, y = -1.4f, width = 2.5f, depth = 2.4f, hasAp = true),
                    SpatialRoomEntity(name = "Studio Office", floorIndex = 2, x = 0.9f, y = -1.2f, width = 1.9f, depth = 2.0f, hasAp = false)
                )
            )
        }
        if (dao.getBulbCount() == 0) {
            dao.insertBulbs(
                listOf(
                    GlobeBulbEntity(
                        name = "Globe Bulb Basement 1",
                        floorIndex = 0,
                        roomName = "Tech Lab",
                        isOn = true,
                        brightnessPct = 90,
                        colorTempKelvin = 4500,
                        lifiSynced = true,
                        lastPulseMs = System.currentTimeMillis()
                    ),
                    GlobeBulbEntity(
                        name = "Globe Hallway Bulb",
                        floorIndex = 0,
                        roomName = "Hallway BSMT",
                        isOn = true,
                        brightnessPct = 75,
                        colorTempKelvin = 4000,
                        lifiSynced = true,
                        lastPulseMs = System.currentTimeMillis()
                    ),
                    GlobeBulbEntity(
                        name = "Globe Living Dimmer",
                        floorIndex = 1,
                        roomName = "Living Room",
                        isOn = false,
                        brightnessPct = 55,
                        colorTempKelvin = 3000,
                        lifiSynced = false,
                        lastPulseMs = 0L
                    ),
                    GlobeBulbEntity(
                        name = "Globe Studio Beacon",
                        floorIndex = 2,
                        roomName = "Studio Office",
                        isOn = true,
                        brightnessPct = 85,
                        colorTempKelvin = 5000,
                        lifiSynced = true,
                        lastPulseMs = System.currentTimeMillis()
                    )
                )
            )
        }
    }

    suspend fun addRoom(room: SpatialRoom) {
        dao.insertRoom(room.toEntity())
    }

    suspend fun deleteRoom(id: Long) {
        dao.deleteRoom(id)
    }

    suspend fun addBulb(bulb: GlobeBulb) {
        dao.insertBulb(bulb.toEntity())
    }

    suspend fun updateBulb(bulb: GlobeBulb) {
        dao.updateBulb(bulb.toEntity())
    }

    suspend fun setAllBulbs(isOn: Boolean) {
        dao.setAllBulbsState(isOn)
    }

    suspend fun markActiveBulbsPulsed() {
        dao.markActiveBulbsPulsed(System.currentTimeMillis())
    }

    suspend fun deleteBulb(id: Long) {
        dao.deleteBulb(id)
    }

    suspend fun saveInsight(title: String, summary: String, category: String, healthScore: Int) {
        dao.insertInsight(
            AiInsightEntity(
                title = title,
                summary = summary,
                category = category,
                healthScore = healthScore,
                timestampMs = System.currentTimeMillis()
            )
        )
    }

    suspend fun clearInsights() = dao.clearInsights()
}
