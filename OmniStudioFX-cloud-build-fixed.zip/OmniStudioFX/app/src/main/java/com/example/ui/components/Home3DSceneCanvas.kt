package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FloorLevel
import com.example.data.model.GlobeBulb
import com.example.data.model.SceneViewMode
import com.example.data.model.SpatialRoom
import com.example.data.model.WifiNetworkNode
import com.example.ui.theme.AmberCalibration
import com.example.ui.theme.CoralAlert
import com.example.ui.theme.DeepSpaceBg
import com.example.ui.theme.HoloCyan
import com.example.ui.theme.JetBrainsMonoFont
import com.example.ui.theme.SpaceBorder
import com.example.ui.theme.SpaceCard
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.ZGateEmerald
import kotlin.math.cos
import kotlin.math.sin

private data class Vec3(val x: Float, val y: Float, val z: Float)

@Composable
fun Home3DSceneCanvas(
    activeFloor: FloorLevel,
    viewMode: SceneViewMode,
    yawDeg: Float,
    pitchDeg: Float,
    zoomScale: Float,
    rooms: List<SpatialRoom>,
    bulbs: List<GlobeBulb>,
    wifiNodes: List<WifiNetworkNode>,
    slabThresholdDb: Float,
    onDragRotate: (deltaYaw: Float, deltaPitch: Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val textMeasurer = rememberTextMeasurer()
    val pulseTransition = rememberInfiniteTransition(label = "wifi_pulse")
    val wavePhase by pulseTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2600, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave_phase"
    )

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(
                Brush.radialGradient(
                    colors = listOf(Color(0xFF0E1D36), DeepSpaceBg)
                )
            )
            .border(1.dp, SpaceBorder, RoundedCornerShape(18.dp))
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    onDragRotate(dragAmount.x * 0.45f, -dragAmount.y * 0.35f)
                }
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val baseScale = minOf(w, h) * 0.095f * zoomScale
            val yawRad = Math.toRadians(yawDeg.toDouble())
            val pitchRad = Math.toRadians(pitchDeg.toDouble())

            fun project(v: Vec3): Offset {
                // Rotate around Z (yaw), then tilt around X (pitch)
                val rx = v.x * cos(yawRad) - v.y * sin(yawRad)
                val ry = v.x * sin(yawRad) + v.y * cos(yawRad)
                val rz = v.z

                val py = ry * cos(pitchRad) - rz * sin(pitchRad)
                val pz = ry * sin(pitchRad) + rz * cos(pitchRad)
                val perspective = 1f / (1f - (pz * 0.035).coerceIn(-0.45, 0.45))

                return Offset(
                    x = (w * 0.5f) + (rx * baseScale * perspective).toFloat(),
                    y = (h * 0.54f) + (py * baseScale * perspective * 0.72f - rz * baseScale * 0.88f).toFloat()
                )
            }

            // Starfield / spatial telemetry particles
            for (i in 0 until 28) {
                val px = ((i * 137) % 100) / 100f * w
                val py = ((i * 73) % 100) / 100f * h
                drawCircle(
                    color = HoloCyan.copy(alpha = if (i % 3 == 0) 0.25f else 0.10f),
                    radius = if (i % 4 == 0) 2.2f else 1.3f,
                    center = Offset(px, py)
                )
            }

            val floorsToRender = if (viewMode == SceneViewMode.FULL_HOUSE_3D) {
                listOf(0, 1, 2)
            } else {
                listOf(activeFloor.index)
            }

            floorsToRender.forEach { floorIdx ->
                val isCurrent = floorIdx == activeFloor.index
                val baseZ = when {
                    viewMode != SceneViewMode.FULL_HOUSE_3D -> 0f
                    floorIdx == 0 -> -2.2f
                    floorIdx == 1 -> 0f
                    else -> 2.2f
                }
                val slabColor = if (isCurrent) HoloCyan else HoloCyan.copy(alpha = 0.28f)
                val slabStroke = if (isCurrent) 2.2f else 1.2f

                // Outer floor perimeter wireframe (-3.6..3.6, -2.8..2.8)
                val hw = 3.5f
                val hd = 2.6f
                val wallH = if (isCurrent) 1.25f else 0.9f
                val cornersBottom = listOf(
                    Vec3(-hw, -hd, baseZ),
                    Vec3(hw, -hd, baseZ),
                    Vec3(hw, hd, baseZ),
                    Vec3(-hw, hd, baseZ)
                ).map(::project)
                val cornersTop = listOf(
                    Vec3(-hw, -hd, baseZ + wallH),
                    Vec3(hw, -hd, baseZ + wallH),
                    Vec3(hw, hd, baseZ + wallH),
                    Vec3(-hw, hd, baseZ + wallH)
                ).map(::project)

                for (i in 0 until 4) {
                    val next = (i + 1) % 4
                    drawLine(slabColor, cornersBottom[i], cornersBottom[next], strokeWidth = slabStroke)
                    if (isCurrent || viewMode == SceneViewMode.FULL_HOUSE_3D) {
                        drawLine(
                            slabColor.copy(alpha = if (isCurrent) 0.55f else 0.2f),
                            cornersTop[i],
                            cornersTop[next],
                            strokeWidth = 1.3f
                        )
                        drawLine(
                            slabColor.copy(alpha = if (isCurrent) 0.5f else 0.18f),
                            cornersBottom[i],
                            cornersTop[i],
                            strokeWidth = 1.3f
                        )
                    }
                }

                // Interior coordinate grid on active floor
                if (isCurrent) {
                    val gridColor = HoloCyan.copy(alpha = 0.14f)
                    for (gx in -2..2 step 2) {
                        drawLine(
                            gridColor,
                            project(Vec3(gx.toFloat(), -hd, baseZ)),
                            project(Vec3(gx.toFloat(), hd, baseZ)),
                            strokeWidth = 1f
                        )
                    }
                    for (gy in -2..2 step 2) {
                        drawLine(
                            gridColor,
                            project(Vec3(-hw, gy.toFloat(), baseZ)),
                            project(Vec3(hw, gy.toFloat(), baseZ)),
                            strokeWidth = 1f
                        )
                    }
                }

                // Rooms extruded on floor
                val floorRooms = rooms.filter { it.floorIndex == floorIdx }
                floorRooms.forEach { room ->
                    val rColor = if (isCurrent) ZGateEmerald.copy(alpha = 0.72f) else HoloCyan.copy(alpha = 0.25f)
                    val x1 = room.x.coerceIn(-3.3f, 2.5f)
                    val y1 = room.y.coerceIn(-2.4f, 1.8f)
                    val x2 = (x1 + room.width).coerceAtMost(3.3f)
                    val y2 = (y1 + room.depth).coerceAtMost(2.4f)
                    val rBot = listOf(
                        Vec3(x1, y1, baseZ),
                        Vec3(x2, y1, baseZ),
                        Vec3(x2, y2, baseZ),
                        Vec3(x1, y2, baseZ)
                    ).map(::project)
                    val rTop = listOf(
                        Vec3(x1, y1, baseZ + wallH * 0.78f),
                        Vec3(x2, y1, baseZ + wallH * 0.78f),
                        Vec3(x2, y2, baseZ + wallH * 0.78f),
                        Vec3(x1, y2, baseZ + wallH * 0.78f)
                    ).map(::project)

                    for (i in 0 until 4) {
                        val next = (i + 1) % 4
                        drawLine(rColor, rBot[i], rBot[next], strokeWidth = if (isCurrent) 1.8f else 1f)
                        if (isCurrent) {
                            drawLine(rColor.copy(alpha = 0.45f), rTop[i], rTop[next], strokeWidth = 1.1f)
                            drawLine(rColor.copy(alpha = 0.45f), rBot[i], rTop[i], strokeWidth = 1.1f)
                        }
                    }

                    if (isCurrent) {
                        val labelPt = project(Vec3((x1 + x2) / 2f, (y1 + y2) / 2f, baseZ + 0.15f))
                        drawCanvasLabel(textMeasurer, room.name, labelPt, TextSecondary)
                    }
                }

                // Globe Suite smart bulbs on floor
                val floorBulbs = bulbs.filter { it.floorIndex == floorIdx }
                floorBulbs.forEachIndexed { idx, bulb ->
                    val bx = -2.0f + (idx * 1.6f)
                    val by = if (idx % 2 == 0) -0.9f else 0.9f
                    val pt = project(Vec3(bx, by, baseZ + wallH * 0.65f))
                    val bulbColor = when {
                        !bulb.isOn -> Color(0xFF475569)
                        bulb.lifiSynced -> AmberCalibration
                        else -> HoloCyan
                    }
                    if (bulb.isOn) {
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(bulbColor.copy(alpha = 0.55f), Color.Transparent),
                                center = pt,
                                radius = 26f
                            ),
                            radius = 26f,
                            center = pt
                        )
                    }
                    drawCircle(color = bulbColor, radius = if (isCurrent) 6.5f else 4f, center = pt)
                }
            }

            // Holographic Wi-Fi wave origin at center of active floor
            val activeBaseZ = when {
                viewMode != SceneViewMode.FULL_HOUSE_3D -> 0f
                activeFloor.index == 0 -> -2.2f
                activeFloor.index == 1 -> 0f
                else -> 2.2f
            }
            val apCenter = project(Vec3(0f, 0f, activeBaseZ + 0.35f))
            for (ring in 0 until 3) {
                val p = (wavePhase + ring * 0.33f) % 1f
                val rad = (18f + p * 120f) * zoomScale
                drawCircle(
                    color = HoloCyan.copy(alpha = (1f - p) * 0.48f),
                    radius = rad,
                    center = apCenter,
                    style = Stroke(width = 2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f)))
                )
            }
            drawCircle(color = HoloCyan, radius = 7f, center = apCenter)

            // Detected Wi-Fi nodes projected by AoA & distance
            wifiNodes.take(8).forEach { node ->
                val angleRad = Math.toRadians(node.aoaDeg.toDouble())
                val clampedDist = (node.estimatedDistanceM / 4.2f).coerceIn(0.6f, 3.2f)
                val nx = (cos(angleRad) * clampedDist).toFloat()
                val ny = (sin(angleRad) * clampedDist * 0.72f).toFloat()
                val nodeFloorZ = when {
                    viewMode != SceneViewMode.FULL_HOUSE_3D -> if (node.isRejectedByZGate) 1.55f else 0.25f
                    node.floorGuess == 0 -> -1.9f
                    node.floorGuess == 1 -> 0.3f
                    else -> 2.5f
                }
                val nPt = project(Vec3(nx, ny, nodeFloorZ))
                val nodeColor = when {
                    node.isRogueSuspect -> AmberCalibration
                    node.isRejectedByZGate -> CoralAlert
                    else -> ZGateEmerald
                }
                drawLine(
                    color = nodeColor.copy(alpha = 0.45f),
                    start = apCenter,
                    end = nPt,
                    strokeWidth = 1.6f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
                )
                drawCircle(color = nodeColor.copy(alpha = 0.25f), radius = 15f, center = nPt)
                drawCircle(color = nodeColor, radius = 6f, center = nPt)
                drawCanvasLabel(
                    textMeasurer,
                    "${node.ssid.take(10)} • ${"%.1f".format(node.estimatedDistanceM)}m",
                    nPt + Offset(8f, -14f),
                    nodeColor
                )
            }
        }

        // Top-left HUD telemetry tag
        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(10.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(SpaceCard.copy(alpha = 0.85f))
                .border(1.dp, SpaceBorder, RoundedCornerShape(8.dp))
                .padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
            Text(
                text = "MODE: ${activeFloor.shortCode} • ${if (viewMode == SceneViewMode.FULL_HOUSE_3D) "3-FLOOR" else "SLAB FX"}",
                style = MaterialTheme.typography.labelSmall,
                color = HoloCyan
            )
            Text(
                text = "YAW ${yawDeg.toInt()}° • PITCH ${pitchDeg.toInt()}° • x${"%.1f".format(zoomScale)}",
                style = MaterialTheme.typography.labelSmall,
                color = TextPrimary
            )
        }

        // Bottom-left Slab threshold readout
        Text(
            text = "Z-Gate Slab: ${"%.1f".format(slabThresholdDb)} dB",
            style = MaterialTheme.typography.labelSmall,
            color = ZGateEmerald,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(10.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(SpaceCard.copy(alpha = 0.82f))
                .padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawCanvasLabel(
    textMeasurer: TextMeasurer,
    text: String,
    topLeft: Offset,
    color: Color
) {
    val result = textMeasurer.measure(
        text = text,
        style = TextStyle(
            fontFamily = JetBrainsMonoFont,
            fontSize = 9.sp,
            color = color
        )
    )
    if (topLeft.x in 0f..(size.width - result.size.width) &&
        topLeft.y in 0f..(size.height - result.size.height)
    ) {
        drawText(result, topLeft = topLeft)
    }
}
