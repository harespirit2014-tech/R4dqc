package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.local.UserSettings
import com.example.data.model.FloorLevel
import com.example.data.model.GlobeBulb
import com.example.data.model.LiFiStatus
import com.example.ui.components.AddBulbDialog
import com.example.ui.components.LiFiEyeDiagramAndConstellation
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPillBadge
import com.example.ui.components.TelemetryStatCard
import com.example.ui.theme.AmberCalibration
import com.example.ui.theme.DeepSpaceBg
import com.example.ui.theme.HoloCyan
import com.example.ui.theme.SpaceBorder
import com.example.ui.theme.SpaceCard
import com.example.ui.theme.SpaceCardElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.ZGateEmerald

@Composable
fun LiFiGlobeScreen(
    settings: UserSettings,
    lifi: LiFiStatus,
    bulbs: List<GlobeBulb>,
    onLinkGlobe: (String) -> Unit,
    onUnlinkGlobe: () -> Unit,
    onOpenGlobeApp: () -> Unit,
    onShareGlobeScene: () -> Unit,
    onToggleLuxRx: () -> Unit,
    onTriggerLiFiPulse: () -> Unit,
    onToggleBulb: (GlobeBulb) -> Unit,
    onSetBulbBrightness: (GlobeBulb, Int) -> Unit,
    onSetAllBulbs: (Boolean) -> Unit,
    onAddBulb: (String, Int, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var emailInput by remember(settings.globeAccountEmail) {
        mutableStateOf(settings.globeAccountEmail)
    }
    var showAddBulbDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column {
                Text(
                    text = "LiFi Optical Link & Globe Suite™",
                    style = MaterialTheme.typography.headlineMedium,
                    color = TextPrimary
                )
                Text(
                    text = "Easy-to-use Globe Suite (Tuya / Smart Life) bridge with LED optical modulation & Lux RX.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            }
        }

        // Optical LiFi Eye Diagram + Lux RX
        item {
            Surface(
                color = SpaceCard,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, SpaceBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Optical Eye Diagram & Constellation",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary
                        )
                        StatusPillBadge(
                            text = if (lifi.isTorchLit) "LED TX PULSE" else lifi.rxStatusText,
                            color = if (lifi.isTorchLit) AmberCalibration else HoloCyan
                        )
                    }

                    LiFiEyeDiagramAndConstellation(
                        lifi = lifi,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        TelemetryStatCard(
                            label = "Ambient Lux",
                            value = if (lifi.hasLightSensor) "${"%.0f".format(lifi.currentLux)} lx" else "No Sensor",
                            valueColor = AmberCalibration,
                            modifier = Modifier.weight(1f)
                        )
                        TelemetryStatCard(
                            label = "Optical SNR",
                            value = if (lifi.isRxActive) "${"%.1f".format(lifi.snrDb)} dB" else "-- dB",
                            valueColor = ZGateEmerald,
                            modifier = Modifier.weight(1f)
                        )
                        TelemetryStatCard(
                            label = "Link Rate",
                            value = if (lifi.isRxActive) "${lifi.estimatedBitrateKbps} kbps" else "Ready",
                            valueColor = HoloCyan,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onToggleLuxRx,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (lifi.isRxActive) ZGateEmerald else HoloCyan,
                                contentColor = DeepSpaceBg
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("toggle_lux_rx_btn")
                        ) {
                            Text(if (lifi.isRxActive) "Stop Lux RX" else "Start Lux RX")
                        }
                        Button(
                            onClick = onTriggerLiFiPulse,
                            enabled = !lifi.isTxActive,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = AmberCalibration,
                                contentColor = DeepSpaceBg
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("lifi_pulse_btn")
                        ) {
                            Icon(Icons.Default.FlashlightOn, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(if (lifi.isTxActive) "Pulsing..." else "LiFi Pulse")
                        }
                    }
                }
            }
        }

        // Easy 3-Step Globe Suite Bridge
        item {
            Surface(
                color = SpaceCard,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, SpaceBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        SectionHeader(
                            title = "Globe Suite™ Bridge",
                            subtitle = "Tuya / Smart Life Optical Sync",
                            icon = Icons.Default.Link
                        )
                        StatusPillBadge(
                            text = if (settings.globeLinked) "Linked" else "Disconnected",
                            color = if (settings.globeLinked) ZGateEmerald else TextMuted
                        )
                    }

                    // Step 1: Account link
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = emailInput,
                            onValueChange = { emailInput = it },
                            label = { Text("Globe Suite Account Email") },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("globe_email_input")
                        )
                        Button(
                            onClick = {
                                if (settings.globeLinked) onUnlinkGlobe() else onLinkGlobe(emailInput)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (settings.globeLinked) SpaceCardElevated else ZGateEmerald,
                                contentColor = if (settings.globeLinked) TextPrimary else DeepSpaceBg
                            ),
                            modifier = Modifier
                                .height(54.dp)
                                .testTag("link_globe_btn")
                        ) {
                            Text(if (settings.globeLinked) "Unlink" else "Link")
                        }
                    }

                    // Step 2: Direct Android App Launch & Scene Share
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onOpenGlobeApp,
                            colors = ButtonDefaults.buttonColors(containerColor = HoloCyan, contentColor = DeepSpaceBg),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("open_globe_app_btn")
                        ) {
                            Icon(Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Open Globe App")
                        }
                        OutlinedButton(
                            onClick = onShareGlobeScene,
                            border = BorderStroke(1.dp, SpaceBorder),
                            modifier = Modifier
                                .height(48.dp)
                                .testTag("share_globe_scene_btn")
                        ) {
                            Icon(Icons.Default.Share, contentDescription = "Share scene", tint = TextPrimary)
                            Spacer(Modifier.width(6.dp))
                            Text("Sync Export", color = TextPrimary)
                        }
                    }

                    // Step 3: Batch Controls
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onSetAllBulbs(true) },
                            colors = ButtonDefaults.buttonColors(containerColor = SpaceCardElevated, contentColor = ZGateEmerald),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("all_bulbs_on_btn")
                        ) {
                            Text("All On")
                        }
                        Button(
                            onClick = { onSetAllBulbs(false) },
                            colors = ButtonDefaults.buttonColors(containerColor = SpaceCardElevated, contentColor = TextSecondary),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("all_bulbs_off_btn")
                        ) {
                            Text("All Off")
                        }
                        Button(
                            onClick = { showAddBulbDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = SpaceCardElevated, contentColor = HoloCyan),
                            modifier = Modifier
                                .height(48.dp)
                                .testTag("add_bulb_btn")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Add light")
                        }
                    }
                }
            }
        }

        item {
            SectionHeader(
                title = "Synced Globe Suite Bulbs (${bulbs.count { it.isOn }}/${bulbs.size} ON)",
                subtitle = "Frame: ${lifi.activeFrameHex}",
                icon = Icons.Default.Lightbulb,
                accent = AmberCalibration
            )
        }

        items(bulbs, key = { it.id }) { bulb ->
            GlobeBulbCard(
                bulb = bulb,
                onToggle = { onToggleBulb(bulb) },
                onBrightnessChange = { onSetBulbBrightness(bulb, it) }
            )
        }
    }

    if (showAddBulbDialog) {
        AddBulbDialog(
            initialFloorIndex = settings.selectedFloorIndex,
            onDismiss = { showAddBulbDialog = false },
            onConfirm = { name, floorIdx, room ->
                onAddBulb(name, floorIdx, room)
                showAddBulbDialog = false
            }
        )
    }
}

@Composable
private fun GlobeBulbCard(
    bulb: GlobeBulb,
    onToggle: () -> Unit,
    onBrightnessChange: (Int) -> Unit
) {
    Surface(
        color = SpaceCard,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, if (bulb.isOn) AmberCalibration.copy(alpha = 0.45f) else SpaceBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(bulb.name, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                    Text(
                        "${FloorLevel.fromIndex(bulb.floorIndex).shortCode} • ${bulb.roomName} • ${if (bulb.lifiSynced) "LiFi Synced" else "Wi-Fi Only"}",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (bulb.lifiSynced) ZGateEmerald else TextSecondary
                    )
                }
                Button(
                    onClick = onToggle,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (bulb.isOn) HoloCyan else SpaceCardElevated,
                        contentColor = if (bulb.isOn) DeepSpaceBg else TextPrimary
                    ),
                    modifier = Modifier.height(48.dp)
                ) {
                    Text(if (bulb.isOn) "Turn Off" else "Turn On")
                }
            }

            if (bulb.isOn) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        "ON • ${bulb.brightnessPct}%",
                        style = MaterialTheme.typography.labelMedium,
                        color = AmberCalibration
                    )
                    Slider(
                        value = bulb.brightnessPct.toFloat(),
                        onValueChange = { onBrightnessChange(it.toInt()) },
                        valueRange = 5f..100f,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}
