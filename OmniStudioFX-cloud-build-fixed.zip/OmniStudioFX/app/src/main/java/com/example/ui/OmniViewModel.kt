package com.example.ui

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ai.GeminiAnalyticsRepository
import com.example.data.local.OmniPreferences
import com.example.data.local.UserSettings
import com.example.data.model.AiAuditResult
import com.example.data.model.AiInsightRecord
import com.example.data.model.ChatMessage
import com.example.data.model.FloorLevel
import com.example.data.model.GlobeBulb
import com.example.data.model.GuidanceState
import com.example.data.model.GuidanceZone
import com.example.data.model.LiFiStatus
import com.example.data.model.SceneViewMode
import com.example.data.model.SensorStatus
import com.example.data.model.SpatialRoom
import com.example.data.model.TelemetryPoint
import com.example.data.remote.FirestoreSyncRepository
import com.example.data.sensors.GlobeSuiteBridge
import com.example.data.sensors.InsightNotificationManager
import com.example.data.sensors.LocationGuidanceManager
import com.example.data.sensors.SensorTelemetryManager
import com.example.data.sensors.TorchLiFiController
import com.example.data.sensors.WifiScanSnapshot
import com.example.data.sensors.WifiTelemetryManager
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.log10

private const val TAG = "OmniViewModel"

sealed interface AiAuditUiState {
    data object Idle : AiAuditUiState
    data object Loading : AiAuditUiState
    data class Success(val result: AiAuditResult) : AiAuditUiState
    data class Error(val message: String) : AiAuditUiState
}

class OmniViewModel(
    appContext: Context,
    private val cloudRepo: FirestoreSyncRepository,
    val currentUserId: String
) : ViewModel() {

    private val preferences = OmniPreferences(appContext)
    private val aiRepository = GeminiAnalyticsRepository()

    private val sensorManager = SensorTelemetryManager(appContext)
    private val wifiManager = WifiTelemetryManager(appContext)
    private val locationManager = LocationGuidanceManager(appContext)
    private val torchController = TorchLiFiController(appContext)
    private val globeBridge = GlobeSuiteBridge(appContext)
    private val notificationManager = InsightNotificationManager(appContext)

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    private val _cloudSyncError = MutableStateFlow<String?>(null)
    val cloudSyncError: StateFlow<String?> = _cloudSyncError.asStateFlow()

    val settings: StateFlow<UserSettings> = combine(
        preferences.settingsFlow,
        cloudRepo.observeProfile(currentUserId)
            .catch { error ->
                val msg = unwrapFirestoreError(error)
                _cloudSyncError.value = msg
                emit(null)
            }
    ) { local, profile ->
        if (profile != null) {
            local.copy(
                slabThresholdDb = profile.slabThresholdDb.toFloat(),
                zGateStrict = profile.zGateStrict,
                globeAccountEmail = profile.globeLinkedEmail ?: local.globeAccountEmail,
                globeLinked = !profile.globeLinkedEmail.isNullOrBlank()
            )
        } else {
            local
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserSettings())

    val rooms: StateFlow<List<SpatialRoom>> = cloudRepo.observeRooms(currentUserId)
        .catch { error ->
            _cloudSyncError.value = unwrapFirestoreError(error)
            emit(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val bulbs: StateFlow<List<GlobeBulb>> = cloudRepo.observeBulbs(currentUserId)
        .catch { error ->
            _cloudSyncError.value = unwrapFirestoreError(error)
            emit(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val insightsHistory: StateFlow<List<AiInsightRecord>> = cloudRepo.observeInsights(currentUserId)
        .catch { error ->
            _cloudSyncError.value = unwrapFirestoreError(error)
            emit(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val sensorStatus: StateFlow<SensorStatus> = sensorManager.sensorStatus
    val wifiSnapshot: StateFlow<WifiScanSnapshot> = wifiManager.snapshot
    val guidanceState: StateFlow<GuidanceState> = locationManager.guidanceState

    private val _sceneViewMode = MutableStateFlow(SceneViewMode.ACTIVE_FLOOR)
    val sceneViewMode: StateFlow<SceneViewMode> = _sceneViewMode.asStateFlow()

    private val _yawDeg = MutableStateFlow(-36f)
    val yawDeg: StateFlow<Float> = _yawDeg.asStateFlow()

    private val _pitchDeg = MutableStateFlow(32f)
    val pitchDeg: StateFlow<Float> = _pitchDeg.asStateFlow()

    private val _zoomScale = MutableStateFlow(1.1f)
    val zoomScale: StateFlow<Float> = _zoomScale.asStateFlow()

    private val _autoOrbit = MutableStateFlow(false)
    val autoOrbit: StateFlow<Boolean> = _autoOrbit.asStateFlow()

    private val _telemetrySeries = MutableStateFlow<List<TelemetryPoint>>(emptyList())
    val telemetrySeries: StateFlow<List<TelemetryPoint>> = _telemetrySeries.asStateFlow()

    private val _aiAuditState = MutableStateFlow<AiAuditUiState>(AiAuditUiState.Idle)
    val aiAuditState: StateFlow<AiAuditUiState> = _aiAuditState.asStateFlow()

    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _isRxActive = MutableStateFlow(false)
    private val _isTxActive = MutableStateFlow(false)
    private val _activeFrameHex = MutableStateFlow("0xA5-GLOBE-SYNC")

    val lifiStatus: StateFlow<LiFiStatus> = combine(
        sensorManager.sensorStatus,
        torchController.hasFlashHardware,
        torchController.isTorchLit,
        _isRxActive,
        _isTxActive
    ) { sensors, hasFlash, torchLit, rxActive, txActive ->
        val lux = sensors.ambientLux ?: 0f
        val snr = if (rxActive) {
            (12f + 10f * log10((lux + 1.5f).toDouble()).toFloat()).coerceIn(6f, 44f)
        } else {
            0f
        }
        val bitrate = if (rxActive) (snr * 18f).toInt().coerceIn(48, 860) else 0
        LiFiStatus(
            isTxActive = txActive,
            isRxActive = rxActive,
            isTorchLit = torchLit,
            hasHardwareFlash = hasFlash,
            hasLightSensor = sensors.hasLightSensor,
            currentLux = lux,
            estimatedBitrateKbps = bitrate,
            snrDb = snr,
            activeFrameHex = _activeFrameHex.value,
            rxStatusText = if (rxActive) "RX: Demodulating (${bitrate} kbps)" else "RX: Ready"
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), LiFiStatus())

    private val _hasNotificationPerm = MutableStateFlow(notificationManager.hasNotificationPermission())
    val hasNotificationPerm: StateFlow<Boolean> = _hasNotificationPerm.asStateFlow()

    private val _hasLocationPerm = MutableStateFlow(locationManager.hasLocationPermission())
    val hasLocationPerm: StateFlow<Boolean> = _hasLocationPerm.asStateFlow()

    private var lastGuidanceZone = GuidanceZone.STANDBY

    init {
        viewModelScope.launch {
            cloudRepo.ensureUserProfileAndSeedDefaults(currentUserId)
                .onFailure { e ->
                    _cloudSyncError.value = e.localizedMessage ?: "Cloud profile sync failed."
                }
        }
        sensorManager.start()
        if (locationManager.hasLocationPermission()) {
            locationManager.startLocationUpdates()
            wifiManager.performScan(
                activeFloorIndex = settings.value.selectedFloorIndex,
                slabThresholdDb = settings.value.slabThresholdDb,
                zGateStrict = settings.value.zGateStrict
            )
        }

        viewModelScope.launch {
            sensorManager.sensorStatus.collect { status ->
                locationManager.updateDeviceAzimuth(status.azimuthDeg)
            }
        }
        viewModelScope.launch {
            torchController.isTorchLit.collect { lit ->
                locationManager.updateTorchActive(lit)
            }
        }
        viewModelScope.launch {
            while (isActive) {
                if (_autoOrbit.value) {
                    _yawDeg.value = (_yawDeg.value + 1.2f) % 360f
                }
                delay(40L)
            }
        }

        viewModelScope.launch {
            while (isActive) {
                val s = sensorManager.sensorStatus.value
                val nodes = wifiManager.snapshot.value.nodes
                val avgRssi = if (nodes.isNotEmpty()) {
                    nodes.map { it.rssiDbm }.average().toFloat()
                } else {
                    -64f
                }
                val doppler = (s.motionVariance * 2.4f + if (nodes.isNotEmpty()) 1.15f else 0.45f)
                    .coerceIn(0.15f, 9.5f)
                val point = TelemetryPoint(
                    timestampMs = System.currentTimeMillis(),
                    pressureHpa = s.pressureHpa,
                    ambientLux = s.ambientLux,
                    avgRssiDbm = avgRssi,
                    dopplerPerturbationDb2 = doppler,
                    locationAccuracyM = locationManager.guidanceState.value.locationAccuracyM
                )
                _telemetrySeries.update { list -> (list + point).takeLast(32) }
                delay(1500L)
            }
        }

        viewModelScope.launch {
            locationManager.guidanceState.collect { g ->
                if (g.isGuiding && g.guidanceZone == GuidanceZone.LOCKED_ON && lastGuidanceZone != GuidanceZone.LOCKED_ON) {
                    if (settings.value.autoAiNotifications) {
                        notificationManager.postInsightNotification(
                            title = "LED Target Aligned: ${g.targetName}",
                            body = "Within ${"%.1f".format(g.distanceMeters ?: 0f)}m on ${FloorLevel.fromIndex(g.targetFloor).label}. Optical beacon locked at 8.0 Hz."
                        )
                    }
                }
                lastGuidanceZone = g.guidanceZone
            }
        }
    }

    private fun unwrapFirestoreError(error: Throwable): String {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val rootError = firestoreError ?: error
        Log.w(TAG, "Firestore stream error", rootError)
        return rootError.message ?: "Firestore sync error"
    }

    fun onPermissionsUpdated() {
        val locGranted = locationManager.hasLocationPermission()
        _hasLocationPerm.value = locGranted
        _hasNotificationPerm.value = notificationManager.hasNotificationPermission()
        if (locGranted) {
            locationManager.startLocationUpdates()
            triggerWifiAndSensorScan()
        }
    }

    fun clearBanner() {
        _statusBanner.value = null
    }

    fun clearCloudError() {
        _cloudSyncError.value = null
    }

    // --- 3D Map & Z-Gate Controls ---

    fun setSceneViewMode(mode: SceneViewMode) {
        _sceneViewMode.value = mode
    }

    fun selectFloor(index: Int) {
        viewModelScope.launch {
            preferences.setSelectedFloor(index)
            wifiManager.reevaluateZGate(index, settings.value.slabThresholdDb, settings.value.zGateStrict)
        }
    }

    fun toggleZGateStrict() {
        viewModelScope.launch {
            val next = !settings.value.zGateStrict
            preferences.setZGateStrict(next)
            cloudRepo.updateZGateProfile(settings.value.slabThresholdDb.toDouble(), next)
                .onFailure { _statusBanner.value = it.localizedMessage ?: "Failed to sync Z-Gate" }
            wifiManager.reevaluateZGate(settings.value.selectedFloorIndex, settings.value.slabThresholdDb, next)
        }
    }

    fun calibrateSlab() {
        viewModelScope.launch {
            sensorManager.recalibrateBarometerBaseline()
            val current = settings.value.slabThresholdDb
            val next = if (current <= -18.0f) -13.5f else current - 1.5f
            preferences.setSlabThresholdDb(next)
            cloudRepo.updateZGateProfile(next.toDouble(), settings.value.zGateStrict)
                .onFailure { _statusBanner.value = it.localizedMessage ?: "Failed to sync slab calibration" }
            wifiManager.reevaluateZGate(settings.value.selectedFloorIndex, next, settings.value.zGateStrict)
            _statusBanner.value = "Slab calibrated to ${"%.1f".format(next)} dB & synced to Firestore."
        }
    }

    fun rotateCamera(deltaYaw: Float, deltaPitch: Float = 0f) {
        _yawDeg.update { (it + deltaYaw) % 360f }
        _pitchDeg.update { (it + deltaPitch).coerceIn(10f, 75f) }
    }

    fun adjustZoom(delta: Float) {
        _zoomScale.update { (it + delta).coerceIn(0.6f, 2.2f) }
    }

    fun toggleAutoOrbit() {
        _autoOrbit.update { !it }
    }

    fun resetCamera() {
        _autoOrbit.value = false
        _yawDeg.value = -36f
        _pitchDeg.value = 32f
        _zoomScale.value = 1.1f
    }

    fun triggerWifiAndSensorScan() {
        val s = settings.value
        wifiManager.performScan(s.selectedFloorIndex, s.slabThresholdDb, s.zGateStrict)
        val rogueCount = wifiManager.snapshot.value.nodes.count { it.isRogueSuspect }
        if (rogueCount > 0 && s.autoAiNotifications) {
            notificationManager.postInsightNotification(
                title = "Wi-Fi Alert: $rogueCount Open/Suspect AP(s)",
                body = "Detected open or unencrypted AP near ${FloorLevel.fromIndex(s.selectedFloorIndex).label}. Review in AI Insights."
            )
        }
    }

    fun addSpatialRoom(name: String, floorIndex: Int, hasAp: Boolean) {
        if (name.isBlank()) return
        viewModelScope.launch {
            val existingOnFloor = rooms.value.count { it.floorIndex == floorIndex }
            val offsetX = ((existingOnFloor % 3) - 1) * 1.8f
            val offsetY = ((existingOnFloor / 3) - 0.5f) * 1.6f
            val result = cloudRepo.addRoom(
                SpatialRoom(
                    name = name.trim(),
                    floorIndex = floorIndex,
                    x = offsetX,
                    y = offsetY,
                    width = 1.7f,
                    depth = 1.5f,
                    hasAp = hasAp
                )
            )
            result.onSuccess {
                _statusBanner.value = "Saved '$name' to Firestore on ${FloorLevel.fromIndex(floorIndex).label}."
            }.onFailure {
                _statusBanner.value = it.localizedMessage ?: "Failed to save room to Firestore."
            }
        }
    }

    fun deleteRoom(room: SpatialRoom) {
        if (room.cloudId.isBlank()) return
        viewModelScope.launch {
            cloudRepo.deleteRoom(room.cloudId)
                .onFailure { _statusBanner.value = it.localizedMessage ?: "Failed to delete room." }
        }
    }

    // --- Gemini AI Analytics & Notifications ---

    fun runGeminiSpatialAudit() {
        viewModelScope.launch {
            _aiAuditState.value = AiAuditUiState.Loading
            try {
                val s = settings.value
                val floor = FloorLevel.fromIndex(s.selectedFloorIndex)
                val result = aiRepository.runSpatialAudit(
                    activeFloor = floor,
                    zGateStrict = s.zGateStrict,
                    slabThresholdDb = s.slabThresholdDb,
                    sensors = sensorStatus.value,
                    wifiNodes = wifiSnapshot.value.nodes,
                    rooms = rooms.value,
                    bulbs = bulbs.value,
                    lifi = lifiStatus.value,
                    guidance = guidanceState.value
                )
                _aiAuditState.value = AiAuditUiState.Success(result)
                cloudRepo.saveInsight(
                    title = result.recommendedAlertTitle,
                    summary = result.spatialSummary,
                    category = "AI Spatial Audit",
                    healthScore = result.healthScore
                )
                if (s.autoAiNotifications) {
                    notificationManager.postInsightNotification(
                        title = result.recommendedAlertTitle,
                        body = result.recommendedAlertBody
                    )
                }
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "AI audit timed out", e)
                _aiAuditState.value = AiAuditUiState.Error("Gemini AI audit timed out after 60s. Please retry.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "AI audit failed", e)
                _aiAuditState.value = AiAuditUiState.Error(e.localizedMessage ?: "Failed to run Gemini AI audit.")
            }
        }
    }

    fun sendCopilotMessage(question: String) {
        val trimmed = question.trim()
        if (trimmed.isEmpty()) return

        val userMsg = ChatMessage(
            id = "u_${System.currentTimeMillis()}",
            isUser = true,
            text = trimmed
        )
        val aiMsgId = "a_${System.currentTimeMillis()}"
        val aiPlaceholder = ChatMessage(
            id = aiMsgId,
            isUser = false,
            text = "",
            isStreaming = true
        )
        _chatMessages.update { it + userMsg + aiPlaceholder }

        viewModelScope.launch {
            try {
                val s = settings.value
                val context = aiRepository.buildTelemetryContext(
                    activeFloor = FloorLevel.fromIndex(s.selectedFloorIndex),
                    zGateStrict = s.zGateStrict,
                    slabThresholdDb = s.slabThresholdDb,
                    sensors = sensorStatus.value,
                    wifiNodes = wifiSnapshot.value.nodes,
                    rooms = rooms.value,
                    bulbs = bulbs.value,
                    lifi = lifiStatus.value,
                    guidance = guidanceState.value
                )
                aiRepository.streamCopilotAnswer(trimmed, context).collect { partial ->
                    _chatMessages.update { list ->
                        list.map {
                            if (it.id == aiMsgId) it.copy(text = partial, isStreaming = true) else it
                        }
                    }
                }
                _chatMessages.update { list ->
                    list.map {
                        if (it.id == aiMsgId) {
                            it.copy(
                                text = it.text.ifBlank { "No response received from Gemini." },
                                isStreaming = false
                            )
                        } else it
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Copilot stream failed", e)
                _chatMessages.update { list ->
                    list.map {
                        if (it.id == aiMsgId) {
                            it.copy(
                                text = "Error: ${e.localizedMessage ?: "Gemini request failed."}",
                                isStreaming = false
                            )
                        } else it
                    }
                }
            }
        }
    }

    fun setAutoNotifications(enabled: Boolean) {
        viewModelScope.launch {
            preferences.setAutoAiNotifications(enabled)
        }
    }

    fun sendTestInsightNotification() {
        val nodesCount = wifiSnapshot.value.nodes.size
        val activeBulbs = bulbs.value.count { it.isOn }
        val floor = FloorLevel.fromIndex(settings.value.selectedFloorIndex)
        val posted = notificationManager.postInsightNotification(
            title = "OmniStudio FX • ${floor.shortCode} Insight",
            body = "$nodesCount Wi-Fi nodes tracked, $activeBulbs Globe Suite lights active. Tap to view live AI telemetry."
        )
        _statusBanner.value = if (posted) {
            "Insight notification dispatched to Android status bar."
        } else {
            "Grant Notification permission to display insight alerts."
        }
    }

    // --- Globe Suite™ & LiFi Optical Link ---

    fun linkGlobeAccount(email: String) {
        val trimmed = email.trim()
        if (trimmed.isBlank()) {
            _statusBanner.value = "Enter your Globe Suite account email first."
            return
        }
        viewModelScope.launch {
            preferences.setGlobeLink(trimmed, true)
            cloudRepo.updateGlobeLinkProfile(trimmed)
                .onSuccess {
                    _activeFrameHex.value = "0xA5-GLOBE-LINK"
                    _statusBanner.value = "Globe Suite profile '$trimmed' linked & synced to Firestore."
                }
                .onFailure {
                    _statusBanner.value = it.localizedMessage ?: "Failed to sync Globe link."
                }
        }
    }

    fun unlinkGlobeAccount() {
        viewModelScope.launch {
            preferences.setGlobeLink("", false)
            cloudRepo.updateGlobeLinkProfile("")
        }
    }

    fun openGlobeSuiteApp() {
        val res = globeBridge.openGlobeSuiteApp()
        _statusBanner.value = res.message
    }

    fun shareGlobeScene() {
        val activeBulbs = bulbs.value.filter { it.isOn }
        val summary = buildString {
            appendLine("OmniStudio FX -> Globe Suite™ LiFi Scene Sync")
            appendLine("Floor: ${FloorLevel.fromIndex(settings.value.selectedFloorIndex).label}")
            appendLine("Optical Frame: ${_activeFrameHex.value}")
            activeBulbs.forEach {
                appendLine("• ${it.name} (${it.roomName}): ON @ ${it.brightnessPct}%")
            }
        }
        globeBridge.shareLiFiSceneToGlobe(summary)
    }

    fun toggleBulb(bulb: GlobeBulb) {
        if (bulb.cloudId.isBlank()) return
        viewModelScope.launch {
            cloudRepo.updateBulbState(
                cloudId = bulb.cloudId,
                powered = !bulb.isOn,
                brightnessPct = bulb.brightnessPct,
                lifiSynced = bulb.lifiSynced
            ).onFailure {
                _statusBanner.value = it.localizedMessage ?: "Failed to update bulb."
            }
        }
    }

    fun setBulbBrightness(bulb: GlobeBulb, pct: Int) {
        if (bulb.cloudId.isBlank()) return
        viewModelScope.launch {
            cloudRepo.updateBulbState(
                cloudId = bulb.cloudId,
                powered = bulb.isOn,
                brightnessPct = pct.coerceIn(5, 100),
                lifiSynced = bulb.lifiSynced
            )
        }
    }

    fun setAllBulbs(isOn: Boolean) {
        viewModelScope.launch {
            cloudRepo.setAllBulbsState(bulbs.value, isOn)
                .onFailure { _statusBanner.value = it.localizedMessage ?: "Failed to update bulbs." }
        }
    }

    fun addGlobeBulb(name: String, floorIndex: Int, roomName: String) {
        if (name.isBlank()) return
        viewModelScope.launch {
            cloudRepo.addBulb(
                GlobeBulb(
                    name = name.trim(),
                    floorIndex = floorIndex,
                    roomName = roomName.ifBlank { "Custom Zone" },
                    isOn = true,
                    brightnessPct = 80,
                    lifiSynced = true,
                    lastPulseMs = System.currentTimeMillis()
                )
            ).onSuccess {
                _statusBanner.value = "Saved Globe Suite device '$name' to Firestore."
            }.onFailure {
                _statusBanner.value = it.localizedMessage ?: "Failed to add bulb."
            }
        }
    }

    fun toggleLuxRx() {
        _isRxActive.update { !it }
    }

    fun triggerLiFiOpticalPulse() {
        _isTxActive.value = true
        _activeFrameHex.value = "0xA5-OOK-${(10..99).random()}"
        torchController.transmitLiFiFrame(
            scope = viewModelScope,
            bits = "1010010111001010101100",
            bitPeriodMs = 75L,
            repeatCount = 3
        ) {
            viewModelScope.launch {
                cloudRepo.markActiveBulbsPulsed(bulbs.value)
                _isTxActive.value = false
                _statusBanner.value = "Optical LiFi frame ${_activeFrameHex.value} pulsed & synced."
            }
        }
    }

    // --- Location Algorithms & LED Guidance ---

    fun selectGuidanceTarget(name: String, floorIndex: Int, offsetIdx: Int) {
        val latOff = 0.00006 * (offsetIdx + 1)
        val lonOff = 0.00005 * (if (offsetIdx % 2 == 0) 1 else -1)
        locationManager.setTarget(name, floorIndex, latOff, lonOff)
        _statusBanner.value = "LED Guidance vector locked to '$name'."
    }

    fun anchorTargetHere() {
        val floor = settings.value.selectedFloorIndex
        locationManager.lockTargetAtCurrentSpot(
            name = "Anchored Zone (${FloorLevel.fromIndex(floor).shortCode})",
            floorIndex = floor
        )
        _statusBanner.value = "Target GPS coordinates anchored to current device position."
    }

    fun toggleLedGuidance() {
        val next = !guidanceState.value.isGuiding
        locationManager.setGuidingActive(next)
        if (next) {
            if (locationManager.hasLocationPermission()) {
                locationManager.startLocationUpdates()
            }
            torchController.startGuidanceLedModulation(viewModelScope) {
                guidanceState.value.ledPulseHz
            }
        } else {
            torchController.stopModulation()
        }
    }

    override fun onCleared() {
        super.onCleared()
        sensorManager.stop()
        locationManager.stopLocationUpdates()
        torchController.release()
    }
}
