package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface OmniDao {
    @Query("SELECT * FROM spatial_rooms ORDER BY floorIndex ASC, id ASC")
    fun observeRooms(): Flow<List<SpatialRoomEntity>>

    @Query("SELECT COUNT(*) FROM spatial_rooms")
    suspend fun getRoomCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRoom(room: SpatialRoomEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRooms(rooms: List<SpatialRoomEntity>)

    @Query("DELETE FROM spatial_rooms WHERE id = :id")
    suspend fun deleteRoom(id: Long)

    @Query("SELECT * FROM globe_bulbs ORDER BY floorIndex ASC, id ASC")
    fun observeBulbs(): Flow<List<GlobeBulbEntity>>

    @Query("SELECT COUNT(*) FROM globe_bulbs")
    suspend fun getBulbCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBulb(bulb: GlobeBulbEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBulbs(bulbs: List<GlobeBulbEntity>)

    @Update
    suspend fun updateBulb(bulb: GlobeBulbEntity)

    @Query("UPDATE globe_bulbs SET isOn = :isOn")
    suspend fun setAllBulbsState(isOn: Boolean)

    @Query("UPDATE globe_bulbs SET lifiSynced = 1, lastPulseMs = :pulseMs WHERE isOn = 1")
    suspend fun markActiveBulbsPulsed(pulseMs: Long)

    @Query("DELETE FROM globe_bulbs WHERE id = :id")
    suspend fun deleteBulb(id: Long)

    @Query("SELECT * FROM ai_insights ORDER BY timestampMs DESC LIMIT 20")
    fun observeInsights(): Flow<List<AiInsightEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInsight(insight: AiInsightEntity): Long

    @Query("DELETE FROM ai_insights")
    suspend fun clearInsights()
}
