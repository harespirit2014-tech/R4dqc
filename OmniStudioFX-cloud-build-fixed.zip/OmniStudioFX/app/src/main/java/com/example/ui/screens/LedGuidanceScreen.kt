package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.FlashlightOff
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.FloorLevel
import com.example.data.model.GlobeBulb
import com.example.data.model.GuidanceState
import com.example.data.model.GuidanceZone
import com.example.ui.components.CompassGuidanceRadar
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPillBadge
import com.example.ui.components.TelemetryStatCard
import com.example.ui.theme.AmberCalibration
import com.example.ui.theme.DeepSpaceBg
import com.example.ui.theme.HoloCyan
import com.example.ui.theme.SpaceBorder
import com.example.ui.theme.SpaceCard
import com.example.ui.theme.SpaceCardElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.ZGateEmerald

@Composable
fun LedGuidanceScreen(
    guidance: GuidanceState,
    bulbs: List<GlobeBulb>,
    hasHardwareFlash: Boolean,
    onRequestLocationPermission: () -> Unit,
    onSelectTarget: (name: String, floorIndex: Int, offsetIdx: Int) -> Unit,
    onAnchorTargetHere: () -> Unit,
    onToggleLedGuidance: () -> Unit,
    modifier: Modifier = Modifier
) {
    val zoneColor = when (guidance.guidanceZone) {
        GuidanceZone.STANDBY -> TextSecondary
        GuidanceZone.SEARCHING -> AmberCalibration
        GuidanceZone.APPROACHING -> HoloCyan
        GuidanceZone.LOCKED_ON -> ZGateEmerald
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column {
                Text(
                    text = "Location Algorithms & LED Guidance",
                    style = MaterialTheme.typography.headlineMedium,
                    color = TextPrimary
                )
                Text(
                    text = "Kalman + Haversine bearing solver guiding you through hardware LED pulse modulation & Globe bulbs.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            }
        }

        if (!guidance.hasLocationPermission) {
            item {
                Surface(
                    color = AmberCalibration.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, AmberCalibration.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            "Grant Location Access for Real-Time LED Guidance",
                            style = MaterialTheme.typography.titleMedium,
                            color = AmberCalibration
                        )
                        Text(
                            "Location coordinates feed the Kalman distance filter, compass bearing vector, and LED frequency modulator.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                        Button(
                            onClick = onRequestLocationPermission,
                            colors = ButtonDefaults.buttonColors(containerColor = AmberCalibration, contentColor = DeepSpaceBg),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("grant_location_guide_btn")
                        ) {
                            Icon(Icons.Default.GpsFixed, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Enable Location Services")
                        }
                    }
                }
            }
        }

        // Compass Radar & LED Beacon Status
        item {
            Surface(
                color = SpaceCard,
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, SpaceBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Target: ${guidance.targetName}",
                                style = MaterialTheme.typography.titleMedium,
                                color = TextPrimary
                            )
                            Text(
                                text = FloorLevel.fromIndex(guidance.targetFloor).label,
                                style = MaterialTheme.typography.labelSmall,
                                color = HoloCyan
                            )
                        }
                        StatusPillBadge(text = guidance.guidanceZone.label, color = zoneColor)
                    }

                    CompassGuidanceRadar(
                        guidance = guidance,
                        modifier = Modifier.size(210.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        TelemetryStatCard(
                            label = "Distance",
                            value = guidance.distanceMeters?.let { "${"%.1f".format(it)} m" } ?: "-- m",
                            valueColor = zoneColor,
                            modifier = Modifier.weight(1f)
                        )
                        TelemetryStatCard(
                            label = "Heading Δ",
                            value = "${guidance.alignmentErrorDeg.toInt()}°",
                            valueColor = HoloCyan,
                            modifier = Modifier.weight(1f)
                        )
                        TelemetryStatCard(
                            label = "LED Pulse",
                            value = "${"%.1f".format(guidance.ledPulseHz)} Hz",
                            valueColor = if (guidance.isTorchActive) AmberCalibration else TextSecondary,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onToggleLedGuidance,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (guidance.isGuiding) AmberCalibration else ZGateEmerald,
                                contentColor = DeepSpaceBg
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("toggle_led_guidance_btn")
                        ) {
                            Icon(
                                if (guidance.isGuiding) Icons.Default.FlashlightOff else Icons.Default.FlashlightOn,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(if (guidance.isGuiding) "Stop LED Guidance" else "Start LED Guidance")
                        }
                        OutlinedButton(
                            onClick = onAnchorTargetHere,
                            border = BorderStroke(1.dp, HoloCyan.copy(alpha = 0.5f)),
                            modifier = Modifier
                                .height(48.dp)
                                .testTag("anchor_target_btn")
                        ) {
                            Icon(Icons.Default.MyLocation, contentDescription = null, tint = HoloCyan, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Anchor Here", color = HoloCyan)
                        }
                    }

                    Text(
                        text = if (hasHardwareFlash) {
                            "Hardware Camera2 LED Torch modulates dynamically: 1.2 Hz (Search) → 2.5–6.0 Hz (Approach) → 8.0 Hz (Lock)."
                        } else {
                            "No rear flash LED detected on this hardware; optical guidance pulse is mirrored on the radar aura."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                }
            }
        }

        // Waypoint Target Selection (Globe Bulbs / Zones)
        item {
            Surface(
                color = SpaceCard,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, SpaceBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    SectionHeader(
                        title = "Select Optical Waypoint",
                        subtitle = "Route to any Globe Suite LED bulb or spatial anchor",
                        icon = Icons.Default.Explore
                    )
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        itemsIndexed(bulbs) { idx, bulb ->
                            FilterChip(
                                selected = guidance.targetName == bulb.name,
                                onClick = { onSelectTarget(bulb.name, bulb.floorIndex, idx) },
                                label = {
                                    Text(
                                        "${bulb.name} (${FloorLevel.fromIndex(bulb.floorIndex).shortCode})",
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                }
                            )
                        }
                    }
                }
            }
        }

        // Location & Kalman Algorithm Live Math Readout
        item {
            Surface(
                color = SpaceCard,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, SpaceBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("Live Algorithm Telemetry", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                    AlgoRow(
                        "Current GPS",
                        if (guidance.currentLat != null && guidance.currentLon != null) {
                            "${"%.5f".format(guidance.currentLat)}, ${"%.5f".format(guidance.currentLon)} (±${guidance.locationAccuracyM?.toInt() ?: 0}m)"
                        } else {
                            "Waiting for location fix..."
                        }
                    )
                    AlgoRow(
                        "Target GPS",
                        if (guidance.targetLat != null && guidance.targetLon != null) {
                            "${"%.5f".format(guidance.targetLat)}, ${"%.5f".format(guidance.targetLon)}"
                        } else {
                            "Not anchored"
                        }
                    )
                    AlgoRow(
                        "Target Bearing / Azimuth",
                        "${guidance.targetBearingDeg.toInt()}° / ${guidance.deviceAzimuthDeg.toInt()}°"
                    )
                    AlgoRow(
                        "Kalman Filter Gain (K)",
                        "${"%.3f".format(guidance.kalmanGain)}"
                    )
                }
            }
        }
    }
}

@Composable
private fun AlgoRow(label: String, value: String) {
    Surface(
        color = SpaceCardElevated,
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
            Text(value, style = MaterialTheme.typography.labelMedium, color = HoloCyan)
        }
    }
}
