package com.example.data.remote

import androidx.annotation.Keep
import com.example.data.model.AiInsightRecord
import com.example.data.model.GlobeBulb
import com.example.data.model.SpatialRoom
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@Keep
@IgnoreExtraProperties
data class CloudUserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "OmniStudio Operator",
    val email: String? = null,
    val globeLinkedEmail: String? = null,
    val slabThresholdDb: Double = -15.5,
    val zGateStrict: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class CloudSpatialRoom(
    @DocumentId val id: String = "",
    val userId: String = "",
    val name: String = "",
    val floorIndex: Long = 0L,
    val posX: Double = 0.0,
    val posY: Double = 0.0,
    val width: Double = 1.8,
    val depth: Double = 1.6,
    val hasAp: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toDomain(): SpatialRoom = SpatialRoom(
        id = id.hashCode().toLong(),
        cloudId = id,
        name = name,
        floorIndex = floorIndex.toInt().coerceIn(0, 2),
        x = posX.toFloat(),
        y = posY.toFloat(),
        width = width.toFloat(),
        depth = depth.toFloat(),
        hasAp = hasAp
    )
}

@Keep
@IgnoreExtraProperties
data class CloudGlobeBulb(
    @DocumentId val id: String = "",
    val userId: String = "",
    val name: String = "",
    val floorIndex: Long = 0L,
    val roomName: String = "",
    val powered: Boolean = false,
    val brightnessPct: Long = 80L,
    val colorTempKelvin: Long = 4000L,
    val lifiSynced: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toDomain(): GlobeBulb = GlobeBulb(
        id = id.hashCode().toLong(),
        cloudId = id,
        name = name,
        floorIndex = floorIndex.toInt().coerceIn(0, 2),
        roomName = roomName,
        isOn = powered,
        brightnessPct = brightnessPct.toInt().coerceIn(0, 100),
        colorTempKelvin = colorTempKelvin.toInt().coerceIn(1800, 6500),
        lifiSynced = lifiSynced,
        lastPulseMs = updatedAt?.toDate()?.time ?: 0L
    )
}

@Keep
@IgnoreExtraProperties
data class CloudAiInsight(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "",
    val summary: String = "",
    val category: String = "AI Spatial Audit",
    val healthScore: Long = 80L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toDomain(): AiInsightRecord = AiInsightRecord(
        id = id.hashCode().toLong(),
        cloudId = id,
        title = title,
        summary = summary,
        category = category,
        healthScore = healthScore.toInt().coerceIn(0, 100),
        timestampMs = createdAt?.toDate()?.time ?: System.currentTimeMillis()
    )
}
