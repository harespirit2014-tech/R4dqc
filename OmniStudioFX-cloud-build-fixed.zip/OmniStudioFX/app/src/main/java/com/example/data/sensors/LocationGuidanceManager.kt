package com.example.data.sensors

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.os.Looper
import androidx.core.content.ContextCompat
import com.example.data.model.GuidanceState
import com.example.data.model.GuidanceZone
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

class LocationGuidanceManager(private val context: Context) {
    private val fusedClient = LocationServices.getFusedLocationProviderClient(context)

    private val _guidanceState = MutableStateFlow(GuidanceState())
    val guidanceState: StateFlow<GuidanceState> = _guidanceState.asStateFlow()

    // Simple 1D Kalman state for distance smoothing
    private var kalmanEstimateDist = 0f
    private var kalmanErrorCov = 1.0f
    private var kalmanInitialized = false

    private val locationCallback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            val loc = result.lastLocation ?: return
            handleNewLocation(loc)
        }
    }

    fun hasLocationPermission(): Boolean {
        val fine = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val granted = fine || coarse
        _guidanceState.update { it.copy(hasLocationPermission = granted) }
        return granted
    }

    @SuppressLint("MissingPermission")
    fun startLocationUpdates() {
        if (!hasLocationPermission()) return
        try {
            fusedClient.lastLocation.addOnSuccessListener { loc ->
                if (loc != null) handleNewLocation(loc)
            }
            val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1500L)
                .setMinUpdateIntervalMillis(800L)
                .build()
            fusedClient.requestLocationUpdates(request, locationCallback, Looper.getMainLooper())
        } catch (_: SecurityException) {
            // Permission revoked
        }
    }

    fun stopLocationUpdates() {
        fusedClient.removeLocationUpdates(locationCallback)
    }

    fun setTarget(name: String, floorIndex: Int, latOffsetDeg: Double = 0.00012, lonOffsetDeg: Double = 0.00008) {
        val current = _guidanceState.value
        val baseLat = current.currentLat ?: 45.5017
        val baseLon = current.currentLon ?: -73.5673
        kalmanInitialized = false
        _guidanceState.update {
            it.copy(
                targetName = name,
                targetFloor = floorIndex,
                targetLat = baseLat + latOffsetDeg,
                targetLon = baseLon + lonOffsetDeg
            )
        }
        recomputeVector()
    }

    fun lockTargetAtCurrentSpot(name: String, floorIndex: Int) {
        val current = _guidanceState.value
        if (current.currentLat != null && current.currentLon != null) {
            kalmanInitialized = false
            _guidanceState.update {
                it.copy(
                    targetName = name,
                    targetFloor = floorIndex,
                    targetLat = current.currentLat,
                    targetLon = current.currentLon
                )
            }
            recomputeVector()
        }
    }

    fun setGuidingActive(active: Boolean) {
        _guidanceState.update { it.copy(isGuiding = active) }
        recomputeVector()
    }

    fun updateDeviceAzimuth(azimuthDeg: Float) {
        _guidanceState.update { it.copy(deviceAzimuthDeg = azimuthDeg) }
        recomputeVector()
    }

    fun updateTorchActive(active: Boolean) {
        _guidanceState.update { it.copy(isTorchActive = active) }
    }

    private fun handleNewLocation(loc: Location) {
        _guidanceState.update { state ->
            // If no target coordinate is anchored yet, place default target ~14m NE of first fix
            val tLat = state.targetLat ?: (loc.latitude + 0.00010)
            val tLon = state.targetLon ?: (loc.longitude + 0.00010)
            state.copy(
                hasLocationPermission = true,
                currentLat = loc.latitude,
                currentLon = loc.longitude,
                locationAccuracyM = loc.accuracy,
                targetLat = tLat,
                targetLon = tLon
            )
        }
        recomputeVector()
    }

    private fun recomputeVector() {
        val s = _guidanceState.value
        val cLat = s.currentLat
        val cLon = s.currentLon
        val tLat = s.targetLat
        val tLon = s.targetLon

        if (cLat == null || cLon == null || tLat == null || tLon == null) {
            _guidanceState.update {
                it.copy(
                    guidanceZone = if (it.isGuiding) GuidanceZone.SEARCHING else GuidanceZone.STANDBY,
                    ledPulseHz = if (it.isGuiding) 1.0f else 0f
                )
            }
            return
        }

        val rawDistance = haversineMeters(cLat, cLon, tLat, tLon)
        // 1D Kalman filter update
        val processNoise = 0.08f
        val measurementNoise = ((s.locationAccuracyM ?: 5f).coerceIn(1f, 20f)) * 0.15f
        val smoothedDist = if (!kalmanInitialized) {
            kalmanInitialized = true
            kalmanEstimateDist = rawDistance
            kalmanErrorCov = 1.0f
            rawDistance
        } else {
            val predCov = kalmanErrorCov + processNoise
            val gain = predCov / (predCov + measurementNoise)
            kalmanEstimateDist += gain * (rawDistance - kalmanEstimateDist)
            kalmanErrorCov = (1f - gain) * predCov
            _guidanceState.update { it.copy(kalmanGain = gain) }
            kalmanEstimateDist
        }

        val bearing = initialBearingDeg(cLat, cLon, tLat, tLon)
        val rawDiff = abs(bearing - s.deviceAzimuthDeg) % 360f
        val alignmentError = if (rawDiff > 180f) 360f - rawDiff else rawDiff

        val zone = when {
            !s.isGuiding -> GuidanceZone.STANDBY
            smoothedDist <= 3.0f && alignmentError <= 25f -> GuidanceZone.LOCKED_ON
            alignmentError <= 35f -> GuidanceZone.APPROACHING
            else -> GuidanceZone.SEARCHING
        }

        // Location-to-LED Frequency Guidance Algorithm:
        // Lock-on -> 8.0 Hz high-rate optical beacon; Approaching -> 2.5..5.5 Hz proportional; Searching -> 1.2 Hz
        val pulseHz = when (zone) {
            GuidanceZone.STANDBY -> 0f
            GuidanceZone.LOCKED_ON -> 8.0f
            GuidanceZone.APPROACHING -> {
                val proximityFactor = (1f - (smoothedDist / 30f).coerceIn(0f, 1f))
                2.5f + proximityFactor * 3.5f
            }
            GuidanceZone.SEARCHING -> 1.2f
        }

        _guidanceState.update {
            it.copy(
                distanceMeters = smoothedDist,
                targetBearingDeg = bearing,
                alignmentErrorDeg = alignmentError,
                guidanceZone = zone,
                ledPulseHz = pulseHz
            )
        }
    }

    private fun haversineMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Float {
        val r = 6371000.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2) * sin(dLat / 2) +
            cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
            sin(dLon / 2) * sin(dLon / 2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return (r * c).toFloat()
    }

    private fun initialBearingDeg(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Float {
        val phi1 = Math.toRadians(lat1)
        val phi2 = Math.toRadians(lat2)
        val dLambda = Math.toRadians(lon2 - lon1)
        val y = sin(dLambda) * cos(phi2)
        val x = cos(phi1) * sin(phi2) - sin(phi1) * cos(phi2) * cos(dLambda)
        return ((Math.toDegrees(atan2(y, x)).toFloat()) + 360f) % 360f
    }
}
