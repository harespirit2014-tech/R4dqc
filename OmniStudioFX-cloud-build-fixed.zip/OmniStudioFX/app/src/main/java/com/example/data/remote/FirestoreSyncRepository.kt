package com.example.data.remote

import android.content.Context
import com.example.R
import com.example.data.model.AiInsightRecord
import com.example.data.model.GlobeBulb
import com.example.data.model.SpatialRoom
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class FirestoreSyncRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    fun observeProfile(userId: String): Flow<CloudUserProfile?> = flow {
        val path = "users/$userId"
        emitAll(
            db.collection("users").document(userId)
                .snapshots()
                .map { snap ->
                    if (snap.exists()) {
                        snap.toObject(
                            CloudUserProfile::class.java,
                            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                        )
                    } else null
                }
                .catch { error ->
                    unwrapAndLog(error, OperationType.GET, path, userId)
                    throw error
                }
        )
    }

    fun observeRooms(userId: String): Flow<List<SpatialRoom>> = flow {
        val path = "users/$userId/rooms"
        emitAll(
            db.collection("users").document(userId).collection("rooms")
                .snapshots()
                .map { snap ->
                    snap.toObjects(
                        CloudSpatialRoom::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).map { it.toDomain() }
                }
                .catch { error ->
                    unwrapAndLog(error, OperationType.LIST, path, userId)
                    throw error
                }
        )
    }

    fun observeBulbs(userId: String): Flow<List<GlobeBulb>> = flow {
        val path = "users/$userId/bulbs"
        emitAll(
            db.collection("users").document(userId).collection("bulbs")
                .snapshots()
                .map { snap ->
                    snap.toObjects(
                        CloudGlobeBulb::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).map { it.toDomain() }
                }
                .catch { error ->
                    unwrapAndLog(error, OperationType.LIST, path, userId)
                    throw error
                }
        )
    }

    fun observeInsights(userId: String): Flow<List<AiInsightRecord>> = flow {
        val path = "users/$userId/insights"
        emitAll(
            db.collection("users").document(userId).collection("insights")
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .limit(20)
                .snapshots()
                .map { snap ->
                    snap.toObjects(
                        CloudAiInsight::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).map { it.toDomain() }
                }
                .catch { error ->
                    unwrapAndLog(error, OperationType.LIST, path, userId)
                    throw error
                }
        )
    }

    suspend fun ensureUserProfileAndSeedDefaults(userId: String): Result<Unit> {
        val userRef = db.collection("users").document(userId)
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user mismatch." }
            val snap = userRef.get().await()
            if (!snap.exists()) {
                val user = auth.currentUser
                val safeDisplay = (user?.displayName?.takeIf { it.isNotBlank() } ?: "OmniStudio Operator")
                    .take(60)
                val profilePayload = mapOf(
                    "userId" to uid,
                    "displayName" to safeDisplay,
                    "email" to user?.email?.take(120),
                    "globeLinkedEmail" to null,
                    "slabThresholdDb" to -15.5,
                    "zGateStrict" to true,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null }
                userRef.set(profilePayload).await()
            }

            // Seed starter 3D rooms & Globe Suite bulbs if this user's cloud workspace is empty
            val roomsSnap = userRef.collection("rooms").limit(1).get().await()
            if (roomsSnap.isEmpty) {
                val starterRooms = listOf(
                    mapOf("name" to "Tech Lab", "floorIndex" to 0L, "posX" to -2.2, "posY" to -1.6, "width" to 2.4, "depth" to 2.0, "hasAp" to true),
                    mapOf("name" to "Hallway BSMT", "floorIndex" to 0L, "posX" to 0.4, "posY" to -1.2, "width" to 1.8, "depth" to 2.4, "hasAp" to false),
                    mapOf("name" to "Living Room", "floorIndex" to 1L, "posX" to -2.0, "posY" to -1.5, "width" to 2.8, "depth" to 2.5, "hasAp" to true),
                    mapOf("name" to "Kitchen", "floorIndex" to 1L, "posX" to 1.0, "posY" to -1.5, "width" to 1.8, "depth" to 2.2, "hasAp" to false),
                    mapOf("name" to "Master Suite", "floorIndex" to 2L, "posX" to -1.8, "posY" to -1.4, "width" to 2.5, "depth" to 2.4, "hasAp" to true),
                    mapOf("name" to "Studio Office", "floorIndex" to 2L, "posX" to 0.9, "posY" to -1.2, "width" to 1.9, "depth" to 2.0, "hasAp" to false)
                )
                starterRooms.forEach { r ->
                    userRef.collection("rooms").document().set(
                        r + mapOf(
                            "userId" to uid,
                            "createdAt" to FieldValue.serverTimestamp(),
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    ).await()
                }
            }

            val bulbsSnap = userRef.collection("bulbs").limit(1).get().await()
            if (bulbsSnap.isEmpty) {
                val starterBulbs = listOf(
                    mapOf("name" to "Globe Bulb Basement 1", "floorIndex" to 0L, "roomName" to "Tech Lab", "powered" to true, "brightnessPct" to 90L, "colorTempKelvin" to 4500L, "lifiSynced" to true),
                    mapOf("name" to "Globe Hallway Bulb", "floorIndex" to 0L, "roomName" to "Hallway BSMT", "powered" to true, "brightnessPct" to 75L, "colorTempKelvin" to 4000L, "lifiSynced" to true),
                    mapOf("name" to "Globe Living Dimmer", "floorIndex" to 1L, "roomName" to "Living Room", "powered" to false, "brightnessPct" to 55L, "colorTempKelvin" to 3000L, "lifiSynced" to false),
                    mapOf("name" to "Globe Studio Beacon", "floorIndex" to 2L, "roomName" to "Studio Office", "powered" to true, "brightnessPct" to 85L, "colorTempKelvin" to 5000L, "lifiSynced" to true)
                )
                starterBulbs.forEach { b ->
                    userRef.collection("bulbs").document().set(
                        b + mapOf(
                            "userId" to uid,
                            "createdAt" to FieldValue.serverTimestamp(),
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    ).await()
                }
            }

            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, userRef.path)
            Result.failure(e)
        }
    }

    suspend fun updateZGateProfile(
        slabThresholdDb: Double,
        zGateStrict: Boolean
    ): Result<Unit> {
        val uid = auth.currentUser?.uid
        val path = "users/${uid ?: "unauthenticated"}"
        return try {
            val activeUid = requireUserId()
            val clampedSlab = slabThresholdDb.coerceIn(-40.0, 0.0)
            db.collection("users").document(activeUid).update(
                mapOf(
                    "slabThresholdDb" to clampedSlab,
                    "zGateStrict" to zGateStrict,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateGlobeLinkProfile(globeEmail: String?): Result<Unit> {
        val uid = auth.currentUser?.uid
        val path = "users/${uid ?: "unauthenticated"}"
        return try {
            val activeUid = requireUserId()
            val safeEmail = globeEmail?.trim()?.take(120).orEmpty()
            db.collection("users").document(activeUid).update(
                mapOf(
                    "globeLinkedEmail" to safeEmail,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun addRoom(room: SpatialRoom): Result<Unit> {
        var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}/rooms"
        return try {
            val uid = requireUserId()
            val cleanName = room.name.trim().take(40)
            require(cleanName.isNotEmpty()) { "Room name must not be blank" }
            val docRef = db.collection("users").document(uid).collection("rooms").document()
            docPath = docRef.path
            val payload = mapOf(
                "userId" to uid,
                "name" to cleanName,
                "floorIndex" to room.floorIndex.toLong().coerceIn(0L, 2L),
                "posX" to room.x.toDouble().coerceIn(-10.0, 10.0),
                "posY" to room.y.toDouble().coerceIn(-10.0, 10.0),
                "width" to room.width.toDouble().coerceIn(0.5, 10.0),
                "depth" to room.depth.toDouble().coerceIn(0.5, 10.0),
                "hasAp" to room.hasAp,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun deleteRoom(cloudId: String): Result<Unit> {
        var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}/rooms/$cloudId"
        return try {
            val uid = requireUserId()
            require(cloudId.isNotBlank()) { "Room cloudId is blank" }
            val docRef = db.collection("users").document(uid).collection("rooms").document(cloudId)
            docPath = docRef.path
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docPath)
            Result.failure(e)
        }
    }

    suspend fun addBulb(bulb: GlobeBulb): Result<Unit> {
        var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}/bulbs"
        return try {
            val uid = requireUserId()
            val cleanName = bulb.name.trim().take(50)
            val cleanRoom = bulb.roomName.trim().ifBlank { "Custom Zone" }.take(40)
            require(cleanName.isNotEmpty()) { "Bulb name must not be blank" }
            val docRef = db.collection("users").document(uid).collection("bulbs").document()
            docPath = docRef.path
            val payload = mapOf(
                "userId" to uid,
                "name" to cleanName,
                "floorIndex" to bulb.floorIndex.toLong().coerceIn(0L, 2L),
                "roomName" to cleanRoom,
                "powered" to bulb.isOn,
                "brightnessPct" to bulb.brightnessPct.toLong().coerceIn(0L, 100L),
                "colorTempKelvin" to bulb.colorTempKelvin.toLong().coerceIn(1800L, 6500L),
                "lifiSynced" to bulb.lifiSynced,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun updateBulbState(
        cloudId: String,
        powered: Boolean,
        brightnessPct: Int,
        lifiSynced: Boolean
    ): Result<Unit> {
        var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}/bulbs/$cloudId"
        return try {
            val uid = requireUserId()
            require(cloudId.isNotBlank()) { "Bulb cloudId must not be blank" }
            val docRef = db.collection("users").document(uid).collection("bulbs").document(cloudId)
            docPath = docRef.path
            docRef.update(
                mapOf(
                    "powered" to powered,
                    "brightnessPct" to brightnessPct.toLong().coerceIn(0L, 100L),
                    "lifiSynced" to lifiSynced,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun setAllBulbsState(bulbs: List<GlobeBulb>, powered: Boolean): Result<Unit> {
        val uidPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}/bulbs"
        return try {
            val uid = requireUserId()
            val batch = db.batch()
            bulbs.filter { it.cloudId.isNotBlank() }.forEach { bulb ->
                val ref = db.collection("users").document(uid).collection("bulbs").document(bulb.cloudId)
                batch.update(
                    ref,
                    mapOf(
                        "powered" to powered,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, uidPath)
            Result.failure(e)
        }
    }

    suspend fun markActiveBulbsPulsed(bulbs: List<GlobeBulb>): Result<Unit> {
        val uidPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}/bulbs"
        return try {
            val uid = requireUserId()
            val batch = db.batch()
            bulbs.filter { it.isOn && it.cloudId.isNotBlank() }.forEach { bulb ->
                val ref = db.collection("users").document(uid).collection("bulbs").document(bulb.cloudId)
                batch.update(
                    ref,
                    mapOf(
                        "lifiSynced" to true,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, uidPath)
            Result.failure(e)
        }
    }

    suspend fun saveInsight(
        title: String,
        summary: String,
        category: String,
        healthScore: Int
    ): Result<Unit> {
        var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}/insights"
        return try {
            val uid = requireUserId()
            val docRef = db.collection("users").document(uid).collection("insights").document()
            docPath = docRef.path
            val payload = mapOf(
                "userId" to uid,
                "title" to title.trim().ifBlank { "AI Spatial Audit" }.take(80),
                "summary" to summary.trim().ifBlank { "Completed telemetry audit." }.take(600),
                "category" to category.trim().ifBlank { "AI Spatial Audit" }.take(40),
                "healthScore" to healthScore.toLong().coerceIn(0L, 100L),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    private fun unwrapAndLog(
        error: Throwable,
        operationType: OperationType,
        path: String,
        userId: String
    ) {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val exceptionToLog = firestoreError ?: (error as? Exception)
        if (exceptionToLog != null && auth.currentUser?.uid == userId) {
            handleFirestoreError(exceptionToLog, operationType, path)
        }
    }
}
