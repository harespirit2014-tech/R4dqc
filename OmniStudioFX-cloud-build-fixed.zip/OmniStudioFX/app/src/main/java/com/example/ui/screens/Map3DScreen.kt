package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RotateLeft
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.WifiFind
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.UserSettings
import com.example.data.model.FloorLevel
import com.example.data.model.GlobeBulb
import com.example.data.model.SceneViewMode
import com.example.data.model.SensorStatus
import com.example.data.model.SpatialRoom
import com.example.data.model.TelemetryPoint
import com.example.data.model.WifiNetworkNode
import com.example.data.sensors.WifiScanSnapshot
import com.example.ui.components.AddRoomDialog
import com.example.ui.components.Home3DSceneCanvas
import com.example.ui.components.OfdmDopplerSpectrogram
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPillBadge
import com.example.ui.components.TelemetryStatCard
import com.example.ui.theme.AmberCalibration
import com.example.ui.theme.CoralAlert
import com.example.ui.theme.DeepSpaceBg
import com.example.ui.theme.HoloCyan
import com.example.ui.theme.SpaceBorder
import com.example.ui.theme.SpaceCard
import com.example.ui.theme.SpaceCardElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.ZGateEmerald

@Composable
fun Map3DScreen(
    settings: UserSettings,
    sensorStatus: SensorStatus,
    wifiSnapshot: WifiScanSnapshot,
    rooms: List<SpatialRoom>,
    bulbs: List<GlobeBulb>,
    telemetrySeries: List<TelemetryPoint>,
    sceneViewMode: SceneViewMode,
    yawDeg: Float,
    pitchDeg: Float,
    zoomScale: Float,
    autoOrbit: Boolean,
    hasLocationPermission: Boolean,
    onRequestLocationPermission: () -> Unit,
    onSelectFloor: (Int) -> Unit,
    onToggleZGate: () -> Unit,
    onCalibrateSlab: () -> Unit,
    onSetViewMode: (SceneViewMode) -> Unit,
    onRotateCamera: (Float, Float) -> Unit,
    onZoom: (Float) -> Unit,
    onToggleAutoOrbit: () -> Unit,
    onResetCamera: () -> Unit,
    onScanNow: () -> Unit,
    onAddRoom: (String, Int, Boolean) -> Unit,
    onDeleteRoom: (SpatialRoom) -> Unit,
    modifier: Modifier = Modifier
) {
    val activeFloor = FloorLevel.fromIndex(settings.selectedFloorIndex)
    var floorMenuExpanded by remember { mutableStateOf(false) }
    var showAddRoomDialog by remember { mutableStateOf(false) }
    var showFullscreen3D by remember { mutableStateOf(false) }

    val acceptedCount = wifiSnapshot.nodes.count { !it.isRejectedByZGate }
    val rejectedCount = wifiSnapshot.nodes.count { it.isRejectedByZGate }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "3D Home Mapping & Wi-Fi Pro",
                        style = MaterialTheme.typography.headlineMedium,
                        color = TextPrimary
                    )
                    Text(
                        text = "Volumetric Z-Gate spatial engine, barometer & 802.11mc RTT.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                }
                FilledTonalButton(
                    onClick = { showFullscreen3D = true },
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = ZGateEmerald,
                        contentColor = DeepSpaceBg
                    ),
                    modifier = Modifier.testTag("fullscreen_3d_btn")
                ) {
                    Icon(Icons.Default.Fullscreen, contentDescription = "Fullscreen 3D", modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("3D Full")
                }
            }
        }

        if (!hasLocationPermission) {
            item {
                Surface(
                    color = AmberCalibration.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, AmberCalibration.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "Location Needed for Live Wi-Fi & RTT",
                                style = MaterialTheme.typography.labelLarge,
                                color = AmberCalibration
                            )
                            Text(
                                "Android requires location access to scan nearby Wi-Fi APs and 802.11mc RTT beacons.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        Button(
                            onClick = onRequestLocationPermission,
                            colors = ButtonDefaults.buttonColors(containerColor = AmberCalibration, contentColor = DeepSpaceBg),
                            modifier = Modifier.testTag("grant_loc_map_btn")
                        ) {
                            Text("Grant")
                        }
                    }
                }
            }
        }

        // 2x2 Telemetry Summary Grid
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TelemetryStatCard(
                        label = "Locked Level",
                        value = activeFloor.label,
                        valueColor = HoloCyan,
                        modifier = Modifier.weight(1f)
                    )
                    TelemetryStatCard(
                        label = "Baro / Rel Z",
                        value = sensorStatus.pressureHpa?.let {
                            "${"%.1f".format(it)} hPa"
                        } ?: "No Baro (${"%.1f".format(sensorStatus.relativeAltitudeM)}m)",
                        valueColor = TextPrimary,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TelemetryStatCard(
                        label = "On My Level",
                        value = "$acceptedCount Detected",
                        valueColor = ZGateEmerald,
                        modifier = Modifier.weight(1f)
                    )
                    TelemetryStatCard(
                        label = "Other Floors",
                        value = "$rejectedCount Rejected",
                        valueColor = CoralAlert,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Floor Dropdown + Z-Gate Filter + Slab Calibration
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(modifier = Modifier.weight(1f)) {
                        OutlinedButton(
                            onClick = { floorMenuExpanded = true },
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, SpaceBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("floor_selector_btn")
                        ) {
                            Text(activeFloor.label, color = TextPrimary, maxLines = 1)
                        }
                        DropdownMenu(
                            expanded = floorMenuExpanded,
                            onDismissRequest = { floorMenuExpanded = false }
                        ) {
                            FloorLevel.entries.forEach { level ->
                                DropdownMenuItem(
                                    text = { Text(level.label) },
                                    onClick = {
                                        floorMenuExpanded = false
                                        onSelectFloor(level.index)
                                    }
                                )
                            }
                        }
                    }

                    Button(
                        onClick = onToggleZGate,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (settings.zGateStrict) ZGateEmerald else SpaceCardElevated,
                            contentColor = if (settings.zGateStrict) DeepSpaceBg else TextPrimary
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .height(48.dp)
                            .testTag("zgate_toggle_btn")
                    ) {
                        Text(
                            if (settings.zGateStrict) "Z-Gate: STRICT" else "Z-Gate: ALL",
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onCalibrateSlab,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AmberCalibration,
                            contentColor = DeepSpaceBg
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .height(48.dp)
                            .testTag("calibrate_slab_btn")
                    ) {
                        Icon(Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Calibrate Slab (${"%.1f".format(settings.slabThresholdDb)} dB)")
                    }
                    Button(
                        onClick = onScanNow,
                        colors = ButtonDefaults.buttonColors(containerColor = HoloCyan, contentColor = DeepSpaceBg),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("scan_wifi_btn")
                    ) {
                        Icon(Icons.Default.WifiFind, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Scan Wi-Fi + RTT")
                    }
                }
            }
        }

        // Scene Mode Segmented Row
        item {
            Surface(
                color = SpaceCard,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, SpaceBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    SceneViewMode.entries.forEach { mode ->
                        val selected = sceneViewMode == mode
                        Button(
                            onClick = { onSetViewMode(mode) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (selected) SpaceCardElevated else Color.Transparent,
                                contentColor = if (selected) HoloCyan else TextSecondary
                            ),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("mode_${mode.name.lowercase()}")
                        ) {
                            Text(
                                text = mode.label,
                                style = MaterialTheme.typography.labelSmall,
                                maxLines = 2
                            )
                        }
                    }
                }
            }
        }

        // Camera Controls + Interactive 3D Canvas
        item {
            Surface(
                color = SpaceCard,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, SpaceBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "3D CAMERA:",
                            style = MaterialTheme.typography.labelMedium,
                            color = HoloCyan
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            IconButton(onClick = { onRotateCamera(-20f, 0f) }) {
                                Icon(Icons.Default.RotateLeft, contentDescription = "Rotate Left", tint = TextPrimary)
                            }
                            IconButton(onClick = { onRotateCamera(20f, 0f) }) {
                                Icon(Icons.Default.RotateRight, contentDescription = "Rotate Right", tint = TextPrimary)
                            }
                            IconButton(onClick = { onZoom(0.15f) }) {
                                Icon(Icons.Default.ZoomIn, contentDescription = "Zoom In", tint = TextPrimary)
                            }
                            IconButton(onClick = { onZoom(-0.15f) }) {
                                Icon(Icons.Default.ZoomOut, contentDescription = "Zoom Out", tint = TextPrimary)
                            }
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = onToggleAutoOrbit,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (autoOrbit) HoloCyan else SpaceCardElevated,
                                contentColor = if (autoOrbit) DeepSpaceBg else TextPrimary
                            ),
                            modifier = Modifier.testTag("auto_orbit_btn")
                        ) {
                            Text(if (autoOrbit) "Auto Orbit: ON" else "Auto Orbit: OFF")
                        }
                        OutlinedButton(
                            onClick = onResetCamera,
                            border = BorderStroke(1.dp, SpaceBorder),
                            modifier = Modifier.testTag("reset_camera_btn")
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Reset View", color = TextPrimary)
                        }
                    }

                    Home3DSceneCanvas(
                        activeFloor = activeFloor,
                        viewMode = sceneViewMode,
                        yawDeg = yawDeg,
                        pitchDeg = pitchDeg,
                        zoomScale = zoomScale,
                        rooms = rooms,
                        bulbs = bulbs,
                        wifiNodes = wifiSnapshot.nodes,
                        slabThresholdDb = settings.slabThresholdDb,
                        onDragRotate = onRotateCamera,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(260.dp)
                    )

                    Text(
                        text = "Drag on the 3D scene to orbit 360° • ${wifiSnapshot.statusNote}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                }
            }
        }

        // Plan Editor Section when Plan Editor mode is active
        if (sceneViewMode == SceneViewMode.PLAN_EDITOR) {
            item {
                Surface(
                    color = SpaceCard,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, HoloCyan.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            SectionHeader(
                                title = "3D Floor Plan Editor",
                                subtitle = "Rooms & AP anchors on ${activeFloor.label}",
                                icon = Icons.Default.MyLocation
                            )
                            Button(
                                onClick = { showAddRoomDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = ZGateEmerald, contentColor = DeepSpaceBg),
                                modifier = Modifier.testTag("add_room_btn")
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Add Room")
                            }
                        }

                        val floorRooms = rooms.filter { it.floorIndex == activeFloor.index }
                        if (floorRooms.isEmpty()) {
                            Text(
                                "No rooms mapped on this floor yet. Tap Add Room to extrude a new 3D zone.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary
                            )
                        } else {
                            floorRooms.forEach { room ->
                                Surface(
                                    color = SpaceCardElevated,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(room.name, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                                            Text(
                                                if (room.hasAp) "Wi-Fi AP Anchor Installed" else "Passive Spatial Zone",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = if (room.hasAp) HoloCyan else TextSecondary
                                            )
                                        }
                                        IconButton(onClick = { onDeleteRoom(room) }) {
                                            Icon(Icons.Default.Delete, contentDescription = "Delete room", tint = CoralAlert)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // OFDM 64-Subcarrier Spectrogram
        item {
            OfdmDopplerSpectrogram(
                telemetrySeries = telemetrySeries,
                motionVariance = sensorStatus.motionVariance,
                modifier = Modifier.fillMaxWidth()
            )
        }

        // Detected Wi-Fi Targets & Z-Gate Filtering List
        item {
            SectionHeader(
                title = "Detected Wi-Fi Nodes & Z-Gate Filtering",
                subtitle = if (wifiSnapshot.isRttHardwareSupported) {
                    "802.11mc FTM RTT hardware supported • ${if (wifiSnapshot.isRttAvailableNow) "Active" else "Standby"}"
                } else {
                    "Using FSPL RSSI + Z-Gate Attenuation Model"
                },
                icon = Icons.Default.Router
            )
        }

        if (wifiSnapshot.nodes.isEmpty()) {
            item {
                Surface(
                    color = SpaceCard,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, SpaceBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Sensors, contentDescription = null, tint = HoloCyan, modifier = Modifier.size(28.dp))
                        Text(
                            "No Wi-Fi scan results loaded yet",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary
                        )
                        Text(
                            "Tap 'Scan Wi-Fi + RTT' above to measure real surrounding APs, RSSI attenuation, and 802.11mc capabilities.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                    }
                }
            }
        } else {
            items(wifiSnapshot.nodes, key = { it.bssid + it.ssid }) { node ->
                WifiNodeZGateCard(node = node)
            }
        }
    }

    if (showAddRoomDialog) {
        AddRoomDialog(
            initialFloorIndex = activeFloor.index,
            onDismiss = { showAddRoomDialog = false },
            onConfirm = { name, floorIdx, hasAp ->
                onAddRoom(name, floorIdx, hasAp)
                showAddRoomDialog = false
            }
        )
    }

    if (showFullscreen3D) {
        Dialog(
            onDismissRequest = { showFullscreen3D = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = DeepSpaceBg
            ) {
                Box(modifier = Modifier.fillMaxSize().padding(12.dp)) {
                    Home3DSceneCanvas(
                        activeFloor = activeFloor,
                        viewMode = sceneViewMode,
                        yawDeg = yawDeg,
                        pitchDeg = pitchDeg,
                        zoomScale = zoomScale,
                        rooms = rooms,
                        bulbs = bulbs,
                        wifiNodes = wifiSnapshot.nodes,
                        slabThresholdDb = settings.slabThresholdDb,
                        onDragRotate = onRotateCamera,
                        modifier = Modifier.fillMaxSize()
                    )
                    IconButton(
                        onClick = { showFullscreen3D = false },
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(8.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close Fullscreen 3D", tint = TextPrimary)
                    }
                }
            }
        }
    }
}

@Composable
private fun WifiNodeZGateCard(node: WifiNetworkNode) {
    val badgeText = when {
        node.isRogueSuspect -> "OPEN / SUSPECT"
        node.isRejectedByZGate -> "REJECTED (${FloorLevel.fromIndex(node.floorGuess).shortCode})"
        else -> "SAME LEVEL"
    }
    val badgeColor = when {
        node.isRogueSuspect -> AmberCalibration
        node.isRejectedByZGate -> CoralAlert
        else -> ZGateEmerald
    }

    Surface(
        color = SpaceCard,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, SpaceBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = node.ssid,
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary
                )
                Text(
                    text = "Dist: ${"%.1f".format(node.estimatedDistanceM)} m • AoA: ${node.aoaDeg}° • Atten Z: ${"%.1f".format(node.zAttenuationDb)} dB",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
                Text(
                    text = "${node.rssiDbm} dBm • ${node.frequencyMhz} MHz • ${if (node.isRttCapable) "802.11mc RTT" else "RSSI Est"}",
                    style = MaterialTheme.typography.labelSmall,
                    color = HoloCyan
                )
            }
            Spacer(Modifier.width(8.dp))
            StatusPillBadge(text = badgeText, color = badgeColor)
        }
    }
}
