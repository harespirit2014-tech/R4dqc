package com.example.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.Lightbulb
import androidx.compose.material.icons.outlined.ViewInAr
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.R
import com.example.data.remote.FirestoreSyncRepository
import com.example.ui.auth.AuthScreen
import com.example.ui.auth.signOutUser
import com.example.ui.components.StatusPillBadge
import com.example.ui.screens.AiAnalyticsScreen
import com.example.ui.screens.LedGuidanceScreen
import com.example.ui.screens.LiFiGlobeScreen
import com.example.ui.screens.Map3DScreen
import com.example.ui.theme.DeepSpaceBg
import com.example.ui.theme.HoloCyan
import com.example.ui.theme.SpaceCard
import com.example.ui.theme.SpaceSurface
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.ZGateEmerald
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

const val ROUTE_MAP_3D = "map_3d"
const val ROUTE_AI_ANALYTICS = "ai_analytics"
const val ROUTE_LIFI_GLOBE = "lifi_globe"
const val ROUTE_LED_GUIDE = "led_guidance"

private data class NavDestination(
    val route: String,
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

private val Destinations = listOf(
    NavDestination(
        route = ROUTE_MAP_3D,
        labelRes = R.string.nav_map_3d,
        selectedIcon = Icons.Filled.ViewInAr,
        unselectedIcon = Icons.Outlined.ViewInAr,
        testTag = "nav_tab_map"
    ),
    NavDestination(
        route = ROUTE_AI_ANALYTICS,
        labelRes = R.string.nav_ai_analytics,
        selectedIcon = Icons.Filled.AutoAwesome,
        unselectedIcon = Icons.Outlined.AutoAwesome,
        testTag = "nav_tab_ai"
    ),
    NavDestination(
        route = ROUTE_LIFI_GLOBE,
        labelRes = R.string.nav_lifi_globe,
        selectedIcon = Icons.Filled.Lightbulb,
        unselectedIcon = Icons.Outlined.Lightbulb,
        testTag = "nav_tab_lifi"
    ),
    NavDestination(
        route = ROUTE_LED_GUIDE,
        labelRes = R.string.nav_led_guide,
        selectedIcon = Icons.Filled.Explore,
        unselectedIcon = Icons.Outlined.Explore,
        testTag = "nav_tab_guide"
    )
)

internal fun FirebaseAuth.authStateFlow(): Flow<FirebaseUser?> = callbackFlow {
    val listener = FirebaseAuth.AuthStateListener { auth ->
        trySend(auth.currentUser)
    }
    addAuthStateListener(listener)
    awaitClose { removeAuthStateListener(listener) }
}

@Composable
fun AppNavigation(auth: FirebaseAuth = Firebase.auth) {
    val currentUser by auth.authStateFlow()
        .collectAsStateWithLifecycle(initialValue = auth.currentUser)

    val user = currentUser
    if (user == null) {
        AuthScreen(onAuthSuccess = { /* AuthStateListener drives transition */ })
    } else {
        key(user.uid) {
            OmniApp(currentUserId = user.uid)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OmniApp(
    currentUserId: String
) {
    val viewModel: OmniViewModel = viewModel(
        key = currentUserId,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) {
                    "APPLICATION_KEY missing from CreationExtras"
                }
                val databaseId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                OmniViewModel(
                    appContext = app.applicationContext,
                    cloudRepo = FirestoreSyncRepository(db),
                    currentUserId = currentUserId
                )
            }
        }
    )

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: ROUTE_MAP_3D

    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val sensorStatus by viewModel.sensorStatus.collectAsStateWithLifecycle()
    val wifiSnapshot by viewModel.wifiSnapshot.collectAsStateWithLifecycle()
    val rooms by viewModel.rooms.collectAsStateWithLifecycle()
    val bulbs by viewModel.bulbs.collectAsStateWithLifecycle()
    val telemetrySeries by viewModel.telemetrySeries.collectAsStateWithLifecycle()
    val sceneViewMode by viewModel.sceneViewMode.collectAsStateWithLifecycle()
    val yawDeg by viewModel.yawDeg.collectAsStateWithLifecycle()
    val pitchDeg by viewModel.pitchDeg.collectAsStateWithLifecycle()
    val zoomScale by viewModel.zoomScale.collectAsStateWithLifecycle()
    val autoOrbit by viewModel.autoOrbit.collectAsStateWithLifecycle()
    val aiAuditState by viewModel.aiAuditState.collectAsStateWithLifecycle()
    val chatMessages by viewModel.chatMessages.collectAsStateWithLifecycle()
    val insightsHistory by viewModel.insightsHistory.collectAsStateWithLifecycle()
    val lifiStatus by viewModel.lifiStatus.collectAsStateWithLifecycle()
    val guidanceState by viewModel.guidanceState.collectAsStateWithLifecycle()
    val statusBanner by viewModel.statusBanner.collectAsStateWithLifecycle()
    val cloudSyncError by viewModel.cloudSyncError.collectAsStateWithLifecycle()
    val hasNotifPerm by viewModel.hasNotificationPerm.collectAsStateWithLifecycle()
    val hasLocPerm by viewModel.hasLocationPerm.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(statusBanner) {
        val msg = statusBanner
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearBanner()
        }
    }

    LaunchedEffect(cloudSyncError) {
        val err = cloudSyncError
        if (!err.isNullOrBlank()) {
            snackbarHostState.showSnackbar("Cloud sync: $err")
            viewModel.clearCloudError()
        }
    }

    val locationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        viewModel.onPermissionsUpdated()
    }

    val notificationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) {
        viewModel.onPermissionsUpdated()
    }

    val requestLocation: () -> Unit = {
        locationLauncher.launch(
            arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            )
        )
    }

    val requestNotifications: () -> Unit = {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            viewModel.onPermissionsUpdated()
        }
    }

    val navigateTo: (String) -> Unit = { route ->
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavRail = maxWidth >= 600.dp

        Scaffold(
            containerColor = DeepSpaceBg,
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = { SnackbarHost(snackbarHostState) },
            topBar = {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = SpaceSurface,
                        titleContentColor = TextPrimary
                    ),
                    title = {
                        Column {
                            Text(
                                text = stringResource(R.string.app_name),
                                style = MaterialTheme.typography.titleLarge
                            )
                            Text(
                                text = stringResource(R.string.app_subtitle),
                                style = MaterialTheme.typography.labelSmall,
                                color = HoloCyan
                            )
                        }
                    },
                    actions = {
                        StatusPillBadge(
                            text = if (settings.zGateStrict) "Cloud + Z-Gate" else "Cloud + All",
                            color = ZGateEmerald
                        )
                        IconButton(
                            onClick = { navigateTo(ROUTE_AI_ANALYTICS) },
                            modifier = Modifier.testTag("top_notifications_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Notifications,
                                contentDescription = "Insights and Notifications",
                                tint = if (hasNotifPerm) HoloCyan else TextSecondary
                            )
                        }
                        IconButton(
                            onClick = { signOutUser(credentialManager, scope) },
                            modifier = Modifier.testTag("sign_out_btn")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Logout,
                                contentDescription = "Sign out",
                                tint = TextSecondary
                            )
                        }
                    }
                )
            },
            bottomBar = {
                if (!useNavRail) {
                    NavigationBar(containerColor = SpaceSurface) {
                        Destinations.forEach { dest ->
                            val selected = currentRoute == dest.route
                            val label = stringResource(dest.labelRes)
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateTo(dest.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = label
                                    )
                                },
                                label = { Text(label, maxLines = 1) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = HoloCyan,
                                    selectedTextColor = HoloCyan,
                                    indicatorColor = SpaceCard,
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary
                                ),
                                modifier = Modifier.testTag(dest.testTag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useNavRail) {
                    NavigationRail(
                        containerColor = SpaceSurface,
                        modifier = Modifier.fillMaxHeight()
                    ) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(vertical = 12.dp)
                        ) {
                            Destinations.forEach { dest ->
                                val selected = currentRoute == dest.route
                                val label = stringResource(dest.labelRes)
                                NavigationRailItem(
                                    selected = selected,
                                    onClick = { navigateTo(dest.route) },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                            contentDescription = label
                                        )
                                    },
                                    label = { Text(label) },
                                    colors = NavigationRailItemDefaults.colors(
                                        selectedIconColor = HoloCyan,
                                        selectedTextColor = HoloCyan,
                                        indicatorColor = SpaceCard,
                                        unselectedIconColor = TextSecondary,
                                        unselectedTextColor = TextSecondary
                                    ),
                                    modifier = Modifier.testTag(dest.testTag)
                                )
                            }
                        }
                    }
                }

                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.TopCenter
                ) {
                    NavHost(
                        navController = navController,
                        startDestination = ROUTE_MAP_3D,
                        modifier = Modifier
                            .fillMaxSize()
                            .widthIn(max = 760.dp)
                    ) {
                        composable(ROUTE_MAP_3D) {
                            Map3DScreen(
                                settings = settings,
                                sensorStatus = sensorStatus,
                                wifiSnapshot = wifiSnapshot,
                                rooms = rooms,
                                bulbs = bulbs,
                                telemetrySeries = telemetrySeries,
                                sceneViewMode = sceneViewMode,
                                yawDeg = yawDeg,
                                pitchDeg = pitchDeg,
                                zoomScale = zoomScale,
                                autoOrbit = autoOrbit,
                                hasLocationPermission = hasLocPerm,
                                onRequestLocationPermission = requestLocation,
                                onSelectFloor = viewModel::selectFloor,
                                onToggleZGate = viewModel::toggleZGateStrict,
                                onCalibrateSlab = viewModel::calibrateSlab,
                                onSetViewMode = viewModel::setSceneViewMode,
                                onRotateCamera = viewModel::rotateCamera,
                                onZoom = viewModel::adjustZoom,
                                onToggleAutoOrbit = viewModel::toggleAutoOrbit,
                                onResetCamera = viewModel::resetCamera,
                                onScanNow = viewModel::triggerWifiAndSensorScan,
                                onAddRoom = viewModel::addSpatialRoom,
                                onDeleteRoom = viewModel::deleteRoom
                            )
                        }

                        composable(ROUTE_AI_ANALYTICS) {
                            AiAnalyticsScreen(
                                settings = settings,
                                sensorStatus = sensorStatus,
                                wifiSnapshot = wifiSnapshot,
                                telemetrySeries = telemetrySeries,
                                aiAuditState = aiAuditState,
                                chatMessages = chatMessages,
                                insightsHistory = insightsHistory,
                                hasNotificationPerm = hasNotifPerm,
                                onRequestNotificationPerm = requestNotifications,
                                onToggleAutoNotify = viewModel::setAutoNotifications,
                                onSendTestNotification = viewModel::sendTestInsightNotification,
                                onRunAiAudit = viewModel::runGeminiSpatialAudit,
                                onSendCopilotMessage = viewModel::sendCopilotMessage
                            )
                        }

                        composable(ROUTE_LIFI_GLOBE) {
                            LiFiGlobeScreen(
                                settings = settings,
                                lifi = lifiStatus,
                                bulbs = bulbs,
                                onLinkGlobe = viewModel::linkGlobeAccount,
                                onUnlinkGlobe = viewModel::unlinkGlobeAccount,
                                onOpenGlobeApp = viewModel::openGlobeSuiteApp,
                                onShareGlobeScene = viewModel::shareGlobeScene,
                                onToggleLuxRx = viewModel::toggleLuxRx,
                                onTriggerLiFiPulse = viewModel::triggerLiFiOpticalPulse,
                                onToggleBulb = viewModel::toggleBulb,
                                onSetBulbBrightness = viewModel::setBulbBrightness,
                                onSetAllBulbs = viewModel::setAllBulbs,
                                onAddBulb = viewModel::addGlobeBulb
                            )
                        }

                        composable(ROUTE_LED_GUIDE) {
                            LedGuidanceScreen(
                                guidance = guidanceState,
                                bulbs = bulbs,
                                hasHardwareFlash = lifiStatus.hasHardwareFlash,
                                onRequestLocationPermission = requestLocation,
                                onSelectTarget = viewModel::selectGuidanceTarget,
                                onAnchorTargetHere = viewModel::anchorTargetHere,
                                onToggleLedGuidance = viewModel::toggleLedGuidance
                            )
                        }
                    }
                }
            }
        }
    }
}
